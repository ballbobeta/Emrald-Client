@echo off
cd /d "%~dp0"
if exist build\libs del /q build\libs\*.jar >nul 2>&1
call gradlew.bat build
if errorlevel 1 (
  echo.
  echo [!] Build failed. Copy the error text above and send it back.
  pause
  exit /b 1
)
echo.
echo DONE. Your mod is: build\libs\emeraldclient-2.0.0.jar
explorer build\libs
pause
