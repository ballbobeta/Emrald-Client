package net.emeraldclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.emeraldclient.module.ModuleManager;
import net.emeraldclient.ui.HudRenderer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public class EmeraldClient implements ClientModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("emeraldclient");
	public static final String MOD_VERSION = "2.0.0";
	
	public static ModuleManager MODULE_MANAGER;
	public static HudRenderer HUD_RENDERER;
	
	@Override
	public void onInitializeClient() {
		LOGGER.info("Initializing Emerald Client v" + MOD_VERSION);
		
		MODULE_MANAGER = new ModuleManager();
		HUD_RENDERER = new HudRenderer();
		
		MODULE_MANAGER.loadModules();
		LOGGER.info("Loaded " + MODULE_MANAGER.getModules().size() + " modules");
	}
}
