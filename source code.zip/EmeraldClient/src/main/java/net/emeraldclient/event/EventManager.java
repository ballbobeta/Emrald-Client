package net.emeraldclient.event;

import java.util.*;

public class EventManager {
	private static final Map<Class<?>, List<EventListener>> LISTENERS = new HashMap<>();
	
	public static void subscribe(Class<?> eventClass, EventListener listener) {
		LISTENERS.computeIfAbsent(eventClass, k -> new ArrayList<>()).add(listener);
	}
	
	public static void unsubscribe(Class<?> eventClass, EventListener listener) {
		List<EventListener> list = LISTENERS.get(eventClass);
		if (list != null) list.remove(listener);
	}
	
	public static void post(Object event) {
		List<EventListener> list = LISTENERS.get(event.getClass());
		if (list != null) {
			for (EventListener listener : list) {
				listener.onEvent(event);
			}
		}
	}
	
	@FunctionalInterface
	public interface EventListener {
		void onEvent(Object event);
	}
}
