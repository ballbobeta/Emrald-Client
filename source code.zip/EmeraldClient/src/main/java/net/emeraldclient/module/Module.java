package net.emeraldclient.module;

import net.minecraft.client.option.KeyBinding;

public abstract class Module {
	protected String name;
	protected String category;
	protected String description;
	protected boolean enabled = false;
	protected KeyBinding keybind = null;
	
	public Module(String name, String category, String description) {
		this.name = name;
		this.category = category;
		this.description = description;
	}
	
	public void onEnable() {}
	public void onDisable() {}
	public void onTick() {}
	public void onRender() {}
	
	public String getName() { return name; }
	public String getCategory() { return category; }
	public String getDescription() { return description; }
	public boolean isEnabled() { return enabled; }
	public void setEnabled(boolean enabled) { this.enabled = enabled; }
	public KeyBinding getKeybind() { return keybind; }
}
