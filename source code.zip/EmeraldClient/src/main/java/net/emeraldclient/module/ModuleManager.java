package net.emeraldclient.module;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
	private List<Module> modules = new ArrayList<>();
	
	public void loadModules() {
		// Combat category (15 modules)
		modules.add(new CombatModule("Crystal Optimizer", "Combat", "Optimizes crystal PvP"));
		modules.add(new CombatModule("Reach Assist", "Combat", "Improves reach detection"));
		modules.add(new CombatModule("Snap Tap", "Combat", "Fast tap assistance"));
		modules.add(new CombatModule("Auto Hit", "Combat", "Automatic hitting"));
		modules.add(new CombatModule("Velocity", "Combat", "Velocity modifier"));
		modules.add(new CombatModule("Backtrack", "Combat", "Backtrack combat assist"));
		modules.add(new CombatModule("Strafe Helper", "Combat", "Strafe assistance"));
		modules.add(new CombatModule("Hit Delay", "Combat", "Hit delay manager"));
		modules.add(new CombatModule("AntiKnockback", "Combat", "Reduce knockback"));
		modules.add(new CombatModule("Criticals", "Combat", "Critical hit enhancer"));
		modules.add(new CombatModule("Swing Bot", "Combat", "Swing animation bot"));
		modules.add(new CombatModule("Killaura", "Combat", "Kill aura assist"));
		modules.add(new CombatModule("Totem Helper", "Combat", "Totem assistance"));
		modules.add(new CombatModule("Hotbar Manager", "Combat", "Hotbar optimization"));
		modules.add(new CombatModule("Sharpness Viewer", "Combat", "Show sharpness level"));
		
		// Player category (12 modules)
		modules.add(new PlayerModule("Sprint", "Player", "Always sprint"));
		modules.add(new PlayerModule("AutoSprint", "Player", "Automatic sprinting"));
		modules.add(new PlayerModule("FastFall", "Player", "Fast fall speed"));
		modules.add(new PlayerModule("Flight", "Player", "Flight mode"));
		modules.add(new PlayerModule("NoFall", "Player", "Prevent fall damage"));
		modules.add(new PlayerModule("AutoClip", "Player", "Auto block clipping"));
		modules.add(new PlayerModule("Speed", "Player", "Speed enhancement"));
		modules.add(new PlayerModule("Step", "Player", "Step up blocks"));
		modules.add(new PlayerModule("FastPlace", "Player", "Fast block placement"));
		modules.add(new PlayerModule("Jesus", "Player", "Walk on water"));
		modules.add(new PlayerModule("NoWeb", "Player", "No cobweb slowdown"));
		modules.add(new PlayerModule("Strider", "Player", "Strider control"));
		
		// Utility category (18 modules)
		modules.add(new UtilityModule("AutoMend", "Utility", "Auto mend items"));
		modules.add(new UtilityModule("ClickGUI", "Utility", "Click menu GUI"));
		modules.add(new UtilityModule("Coordinates", "Utility", "Show coordinates"));
		modules.add(new UtilityModule("Direction", "Utility", "Show direction"));
		modules.add(new UtilityModule("FPS Display", "Utility", "FPS counter"));
		modules.add(new UtilityModule("Ping Display", "Utility", "Ping indicator"));
		modules.add(new UtilityModule("TimeDisplay", "Utility", "Show time"));
		modules.add(new UtilityModule("Watermark", "Utility", "Mod watermark"));
		modules.add(new UtilityModule("FullBright", "Utility", "Full brightness"));
		modules.add(new UtilityModule("Xray", "Utility", "X-ray mode"));
		modules.add(new UtilityModule("Freecam", "Utility", "Free camera"));
		modules.add(new UtilityModule("Zoom", "Utility", "Camera zoom"));
		modules.add(new UtilityModule("ChatFilter", "Utility", "Filter chat"));
		modules.add(new UtilityModule("ItemPhysics", "Utility", "Item physics"));
		modules.add(new UtilityModule("BetterChat", "Utility", "Chat enhancement"));
		modules.add(new UtilityModule("Shaders", "Utility", "Shader support"));
		modules.add(new UtilityModule("Performance", "Utility", "Performance tweaks"));
		modules.add(new UtilityModule("Notifications", "Utility", "Toast notifications"));
		
		// Render category (14 modules)
		modules.add(new RenderModule("Esp", "Render", "Entity ESP"));
		modules.add(new RenderModule("Tracers", "Render", "Player tracers"));
		modules.add(new RenderModule("Wireframe", "Render", "Wireframe view"));
		modules.add(new RenderModule("Nametags", "Render", "Enhanced nametags"));
		modules.add(new RenderModule("Chams", "Render", "Player chams"));
		modules.add(new RenderModule("BlockESP", "Render", "Block ESP"));
		modules.add(new RenderModule("ItemESP", "Render", "Item ESP"));
		modules.add(new RenderModule("Skybox", "Render", "Custom skybox"));
		modules.add(new RenderModule("Particles", "Render", "Custom particles"));
		modules.add(new RenderModule("NightVision", "Render", "Night vision mode"));
		modules.add(new RenderModule("VoidFog", "Render", "Void fog removal"));
		modules.add(new RenderModule("Hand", "Render", "Hand customization"));
		modules.add(new RenderModule("Cape", "Render", "Cape renderer"));
		modules.add(new RenderModule("Animations", "Render", "Custom animations"));
		
		// Info category (10 modules)
		modules.add(new InfoModule("Inventory", "Info", "Inventory viewer"));
		modules.add(new InfoModule("EntityInfo", "Info", "Entity information"));
		modules.add(new InfoModule("PlayerList", "Info", "Enhanced player list"));
		modules.add(new InfoModule("TabFPS", "Info", "Tab FPS display"));
		modules.add(new InfoModule("Metrics", "Info", "Performance metrics"));
		modules.add(new InfoModule("Memory", "Info", "Memory usage"));
		modules.add(new InfoModule("Biome", "Info", "Biome display"));
		modules.add(new InfoModule("NetDebug", "Info", "Network debug"));
		modules.add(new InfoModule("LogViewer", "Info", "Log viewer"));
		modules.add(new InfoModule("Statistics", "Info", "Game statistics"));
	}
	
	public List<Module> getModules() { return modules; }
	public List<Module> getModulesByCategory(String category) {
		return modules.stream().filter(m -> m.getCategory().equals(category)).toList();
	}
}

class CombatModule extends Module {
	CombatModule(String name, String category, String description) {
		super(name, category, description);
	}
}

class PlayerModule extends Module {
	PlayerModule(String name, String category, String description) {
		super(name, category, description);
	}
}

class UtilityModule extends Module {
	UtilityModule(String name, String category, String description) {
		super(name, category, description);
	}
}

class RenderModule extends Module {
	RenderModule(String name, String category, String description) {
		super(name, category, description);
	}
}

class InfoModule extends Module {
	InfoModule(String name, String category, String description) {
		super(name, category, description);
	}
}
