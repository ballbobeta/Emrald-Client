package net.emeraldclient.ui;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class HudRenderer {
	private boolean visible = true;
	private int x = 5;
	private int y = 5;
	
	public void render(DrawContext context, float tickDelta) {
		if (!visible) return;
		
		// Render HUD elements
		// FPS counter
		renderText(context, "FPS: 318", x, y, 0x2eff80);
		// CPS display
		renderText(context, "CPS: 12.4", x, y + 12, 0x2eff80);
		// Reach display
		renderText(context, "REACH: 3.1", x, y + 24, 0x2eff80);
	}
	
	private void renderText(DrawContext context, String text, int x, int y, int color) {
		// TODO: Render text with custom font
	}
	
	public void setVisible(boolean visible) { this.visible = visible; }
	public boolean isVisible() { return visible; }
	public void setPosition(int x, int y) { this.x = x; this.y = y; }
}
