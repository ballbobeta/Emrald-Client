package com.emeraldclient;

import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Finds the enemy you are aiming at and measures distance to its hitbox. */
public final class Targeting {
	private static final double SCAN_RADIUS = 8.0;
	private static final double MIN_AIM_DOT = 0.9;

	private Targeting() {
	}

	public static LivingEntity find(Minecraft mc, LocalPlayer player) {
		if (mc.level == null) {
			return null;
		}
		AABB area = player.getBoundingBox().inflate(SCAN_RADIUS);
		List<Entity> nearby = mc.level.getEntities(player, area, e -> e instanceof LivingEntity && e.isAlive());

		Vec3 eye = player.getEyePosition();
		Vec3 look = player.getLookAngle();

		LivingEntity best = null;
		double bestDot = MIN_AIM_DOT;
		for (Entity e : nearby) {
			Vec3 toCenter = e.getBoundingBox().getCenter().subtract(eye);
			if (toCenter.length() > SCAN_RADIUS) {
				continue;
			}
			double dot = toCenter.normalize().dot(look);
			if (dot > bestDot) {
				bestDot = dot;
				best = (LivingEntity) e;
			}
		}
		return best;
	}

	/** Distance from your eyes to the closest point of the entity's hitbox. */
	public static double distanceToHitbox(LocalPlayer player, Entity target) {
		return Math.sqrt(target.getBoundingBox().distanceToSqr(player.getEyePosition()));
	}
}
