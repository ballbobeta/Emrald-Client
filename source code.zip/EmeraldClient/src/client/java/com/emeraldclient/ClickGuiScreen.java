package com.emeraldclient;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** The Emerald Client menu: sidebar tabs, scrollable module cards, expandable settings. */
public class ClickGuiScreen extends Screen {
	private static final int PANEL_W = 540;
	private static final int PANEL_H = 330;
	private static final int SIDE_W = 128;
	private static final int TOP_H = 46;
	private static final int CARD_H = 42;
	private static final int ROW_H = 24;
	private static final int GAP = 8;
	private static final int TAB_H = 32;

	private static String tab = Modules.INFO;

	private float open;
	private float tabAnim = Modules.CATEGORIES.indexOf(tab);
	private float scroll;
	private float scrollTarget;
	private long lastNs = System.nanoTime();

	private Setting dragSetting;
	private int dragTrackX;
	private int dragTrackW;

	// geometry of the current frame
	private int px;
	private int py;
	private int cx;
	private int cy;
	private int cw;
	private int ch;

	private record Card(Module m, int y, int h) {
	}

	private final Screen parent;

	public ClickGuiScreen() {
		this(null);
	}

	public ClickGuiScreen(Screen parent) {
		super(Component.literal("Emerald Client"));
		this.parent = parent;
	}

	private void geometry() {
		px = (this.width - PANEL_W) / 2;
		py = (this.height - PANEL_H) / 2;
		cx = px + SIDE_W + 14;
		cy = py + TOP_H;
		cw = PANEL_W - SIDE_W - 28;
		ch = PANEL_H - TOP_H - 12;
	}

	private int settingsHeight(Module m) {
		return m.settings.isEmpty() ? 0 : m.settings.size() * ROW_H + 8;
	}

	private List<Card> cards() {
		List<Card> out = new ArrayList<>();
		int y = cy - Math.round(scroll);
		for (Module m : Modules.in(tab)) {
			int h = CARD_H + Math.round(m.expandAnim * settingsHeight(m));
			out.add(new Card(m, y, h));
			y += h + GAP;
		}
		return out;
	}

	private int contentHeight() {
		int h = 0;
		for (Module m : Modules.in(tab)) {
			h += CARD_H + Math.round(m.expandAnim * settingsHeight(m)) + GAP;
		}
		return h;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		try {
			drawScreen(g, mouseX, mouseY, delta);
		} catch (Throwable t) {
			Safe.report("menu draw", t);
			Gfx.alpha = 1.0F;
			this.onClose();
		}
	}

	private void drawScreen(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		long now = System.nanoTime();
		float dt = Math.min(0.05F, (now - lastNs) / 1_000_000_000.0F);
		lastNs = now;
		geometry();
		Font font = Minecraft.getInstance().font;

		open = Gfx.approach(open, 1.0F, dt, 12.0F);
		float ease = Gfx.easeOutCubic(open);
		Gfx.alpha = ease;

		// scroll
		int maxScroll = Math.max(0, contentHeight() - ch);
		scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
		scroll = Gfx.approach(scroll, scrollTarget, dt, 16.0F);
		tabAnim = Gfx.approach(tabAnim, Modules.CATEGORIES.indexOf(tab), dt, 14.0F);

		g.fill(0, 0, this.width, this.height, Gfx.withAlpha(0xFF020604, (int) (150 * ease)));

		float sc = 0.94F + 0.06F * ease;
		g.pose().pushMatrix();
		g.pose().translate(this.width / 2.0F, this.height / 2.0F);
		g.pose().scale(sc);
		g.pose().translate(-this.width / 2.0F, -this.height / 2.0F);

		// panel + sidebar
		Gfx.round(g, px, py, px + PANEL_W, py + PANEL_H, 10, Gfx.PANEL);
		Gfx.round(g, px, py, px + SIDE_W, py + PANEL_H, 10, Gfx.SIDEBAR);
		Gfx.fill(g, px + SIDE_W - 10, py, px + SIDE_W, py + PANEL_H, Gfx.SIDEBAR);
		Gfx.gradientH(g, px + 14, py + 40, SIDE_W - 28, 1, Gfx.ACCENT, Gfx.withAlpha(Gfx.ACCENT2, 0));

		Gfx.scaledText(g, font, "EMERALD", px + 16, py + 14, Gfx.ACCENT2, 1.5F);
		Gfx.text(g, font, "CLIENT", px + 17, py + 29, Gfx.MUTED);

		// tabs
		int ty = py + 56;
		int ind = Math.round(ty + tabAnim * (TAB_H + 4));
		Gfx.round(g, px + 8, ind, px + SIDE_W - 8, ind + TAB_H, 6, Gfx.CARD_HOVER);
		Gfx.round(g, px + 8, ind + 6, px + 11, ind + TAB_H - 6, 1, Gfx.ACCENT);
		for (int i = 0; i < Modules.CATEGORIES.size(); i++) {
			String name = Modules.CATEGORIES.get(i);
			boolean sel = name.equals(tab);
			int y = ty + i * (TAB_H + 4);
			boolean hover = inRect(mouseX, mouseY, px + 8, y, SIDE_W - 16, TAB_H);
			Gfx.text(g, font, name, px + 24, y + 12, sel ? Gfx.TEXT : hover ? Gfx.ACCENT2 : Gfx.MUTED);
			Gfx.text(g, font, String.valueOf(Modules.in(name).size()), px + SIDE_W - 26, y + 12, Gfx.DIM);
		}

		// Edit HUD button
		int bx = px + 12;
		int by = py + PANEL_H - 40;
		int bw = SIDE_W - 24;
		boolean bh = inRect(mouseX, mouseY, bx, by, bw, 28);
		Gfx.round(g, bx, by, bx + bw, by + 28, 6, bh ? Gfx.ACCENT : Gfx.CARD_HOVER);
		Gfx.centered(g, font, "Edit HUD", bx + bw / 2, by + 10, bh ? 0xFF06110B : Gfx.TEXT);

		// header
		Gfx.text(g, font, tab, cx, py + 16, Gfx.TEXT);
		long on = Modules.in(tab).stream().filter(m -> m.enabled).count();
		Gfx.text(g, font, on + " of " + Modules.in(tab).size() + " enabled", cx, py + 28, Gfx.MUTED);
		Gfx.text(g, font, "Esc closes  -  click a card's name to see its settings", px + PANEL_W - 14 - font.width("Esc closes  -  click a card's name to see its settings"), py + 16, Gfx.DIM);

		// cards (clipped)
		g.enableScissor(cx - 2, cy, cx + cw + 2, cy + ch);
		try {
			int idx = 0;
			for (Card c : cards()) {
				drawCard(g, font, c, mouseX, mouseY, dt, idx++);
			}
		} finally {
			g.disableScissor();
		}

		// scrollbar
		if (maxScroll > 0) {
			int trackH = ch;
			int barH = Math.max(24, trackH * ch / (ch + maxScroll));
			int barY = cy + Math.round((trackH - barH) * (scroll / maxScroll));
			Gfx.round(g, px + PANEL_W - 8, barY, px + PANEL_W - 5, barY + barH, 1, Gfx.OFF);
		}

		g.pose().popMatrix();
		Gfx.alpha = 1.0F;
	}

	private void drawCard(GuiGraphicsExtractor g, Font font, Card c, int mx, int my, float dt, int index) {
		Module m = c.m();
		if (c.y() + c.h() < cy || c.y() > cy + ch) {
			// still advance animations
			m.animOn = Gfx.approach(m.animOn, m.enabled ? 1 : 0, dt, 14.0F);
			m.expandAnim = Gfx.approach(m.expandAnim, m.expanded ? 1 : 0, dt, 14.0F);
			return;
		}
		Gfx.spring(m.spring, m.enabled ? 1 : 0, dt);
		m.animOn = Gfx.approach(m.animOn, m.enabled ? 1 : 0, dt, 14.0F);
		m.expandAnim = Gfx.approach(m.expandAnim, m.expanded ? 1 : 0, dt, 14.0F);
		boolean hover = inRect(mx, my, cx, c.y(), cw, CARD_H) && my >= cy && my < cy + ch;
		m.animHover = Gfx.approach(m.animHover, hover ? 1 : 0, dt, 18.0F);

		int accent = Gfx.accent(m.category);
		Gfx.round(g, cx, c.y(), cx + cw, c.y() + c.h(), 8, Gfx.lerp(Gfx.CARD, Gfx.CARD_HOVER, m.animHover));
		// glowing left edge when on
		Gfx.round(g, cx, c.y() + 8, cx + 3, c.y() + CARD_H - 8, 1, Gfx.withAlpha(accent, (int) (255 * Gfx.clamp01(m.animOn))));

		g.fakeItem(m.icon(), cx + 14, c.y() + (CARD_H - 16) / 2);
		Gfx.text(g, font, m.name, cx + 40, c.y() + 10, Gfx.TEXT);
		String desc = m.description;
		int maxW = cw - 40 - 70;
		if (font.width(desc) > maxW) {
			while (desc.length() > 3 && font.width(desc + "...") > maxW) {
				desc = desc.substring(0, desc.length() - 1);
			}
			desc += "...";
		}
		Gfx.text(g, font, desc, cx + 40, c.y() + 23, Gfx.MUTED);

		int sx = cx + cw - 46;
		int sy = c.y() + (CARD_H - 16) / 2;
		Gfx.toggle(g, sx, sy, 32, 16, m.spring[0], accent);
		if (!m.settings.isEmpty()) {
			Gfx.text(g, font, m.expanded ? "v" : ">", cx + cw - 62, c.y() + 17, Gfx.DIM);
		}

		if (m.expandAnim > 0.02F && !m.settings.isEmpty()) {
			float a = Gfx.clamp01(m.expandAnim);
			float save = Gfx.alpha;
			Gfx.alpha = save * a;
			int ry = c.y() + CARD_H + 2;
			for (Setting s : m.settings) {
				drawRow(g, font, m, s, ry, accent);
				ry += ROW_H;
			}
			Gfx.alpha = save;
		}
	}

	private void drawRow(GuiGraphicsExtractor g, Font font, Module m, Setting s, int y, int accent) {
		int x = cx + 14;
		int w = cw - 28;
		Gfx.text(g, font, s.label, x, y + 8, Gfx.MUTED);
		if (s.kind == Setting.Kind.TOGGLE) {
			Gfx.toggle(g, x + w - 30, y + 4, 30, 15, s.on() ? 1 : 0, accent);
			return;
		}
		int trackW = 130;
		int tx = x + w - trackW - 52;
		Gfx.round(g, tx, y + 10, tx + trackW, y + 14, 2, Gfx.TRACK);
		int fill = Math.round(trackW * Gfx.clamp01(s.fraction()));
		Gfx.round(g, tx, y + 10, tx + Math.max(4, fill), y + 14, 2, accent);
		Gfx.round(g, tx + fill - 4, y + 7, tx + fill + 4, y + 17, 4, 0xFFFFFFFF);
		Gfx.text(g, font, s.display(), tx + trackW + 10, y + 8, Gfx.TEXT);
	}

	private static boolean inRect(double mx, double my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	// ------------------------------------------------------------------ input

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (event.button() != 0) {
			return super.mouseClicked(event, doubleClick);
		}
		geometry();
		double mx = event.x();
		double my = event.y();

		for (int i = 0; i < Modules.CATEGORIES.size(); i++) {
			if (inRect(mx, my, px + 8, py + 56 + i * (TAB_H + 4), SIDE_W - 16, TAB_H)) {
				if (!tab.equals(Modules.CATEGORIES.get(i))) {
					tab = Modules.CATEGORIES.get(i);
					scroll = 0;
					scrollTarget = 0;
				}
				return true;
			}
		}
		if (inRect(mx, my, px + 12, py + PANEL_H - 40, SIDE_W - 24, 28)) {
			Modules.save();
			Minecraft.getInstance().setScreen(new HudEditorScreen(this.parent));
			return true;
		}
		if (!inRect(mx, my, cx, cy, cw, ch)) {
			return super.mouseClicked(event, doubleClick);
		}

		for (Card c : cards()) {
			Module m = c.m();
			if (my >= c.y() && my < c.y() + CARD_H && mx >= cx && mx < cx + cw) {
				if (mx >= cx + cw - 54) {
					m.enabled = !m.enabled;
					Modules.save();
				} else if (!m.settings.isEmpty()) {
					m.expanded = !m.expanded;
				} else {
					m.enabled = !m.enabled;
					Modules.save();
				}
				return true;
			}
			if (m.expandAnim > 0.5F) {
				int ry = c.y() + CARD_H + 2;
				for (Setting s : m.settings) {
					if (my >= ry && my < ry + ROW_H && mx >= cx + 10 && mx < cx + cw - 10) {
						if (s.kind == Setting.Kind.TOGGLE) {
							s.flip();
							Modules.save();
						} else {
							int trackW = 130;
							int tx = cx + 14 + cw - 28 - trackW - 52;
							dragSetting = s;
							dragTrackX = tx;
							dragTrackW = trackW;
							s.set(s.min + (s.max - s.min) * Math.max(0, Math.min(1, (mx - tx) / trackW)));
						}
						return true;
					}
					ry += ROW_H;
				}
			}
		}
		return true;
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
		if (dragSetting != null) {
			dragSetting.set(dragSetting.min + (dragSetting.max - dragSetting.min)
					* Math.max(0, Math.min(1, (event.x() - dragTrackX) / dragTrackW)));
			return true;
		}
		return super.mouseDragged(event, dx, dy);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
		if (dragSetting != null) {
			dragSetting = null;
			Modules.save();
			return true;
		}
		return super.mouseReleased(event);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double sx, double sy) {
		scrollTarget -= (float) (sy * 30);
		return true;
	}

	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void onClose() {
		Modules.save();
		Minecraft.getInstance().setScreen(parent);
	}
}
