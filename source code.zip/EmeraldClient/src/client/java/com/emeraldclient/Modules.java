package com.emeraldclient;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Function;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.item.Items;

import net.fabricmc.loader.api.FabricLoader;

/** Every module, plus saving/loading of settings. */
public final class Modules {
	public static final String INFO = "Info";
	public static final String PLAYER = "Player";
	public static final String COMBAT = "Combat";
	public static final String UTILITY = "Utility";
	public static final String PERF = "Performance";
	public static final List<String> CATEGORIES = List.of(INFO, PLAYER, COMBAT, UTILITY, PERF);

	public static final int GREEN = 0xFF2ECC71;
	public static final int YELLOW = 0xFFFFD84D;
	public static final int RED = 0xFFFF5C5C;
	public static final int WHITE = 0xFFEFFAF3;

	/** Saved copy of the video options FPS Boost changed. */
	public static final class Backup {
		public int renderDistance = -1;
		public int simulationDistance;
		public double entityScaling;
		public boolean entityShadows;
		public int biomeBlend;
	}

	public static Backup backup = new Backup();

	/** A HUD box that is just a few text lines. Lines are worked out once per frame, and a failing module switches itself off. */
	private static final class LineHud implements Module.Hud {
		private final Function<Minecraft, List<Line>> live;
		private final List<Line> sample;
		private List<Line> cached = List.of();
		private long cachedFrame = -1;
		private int errors;

		LineHud(Function<Minecraft, List<Line>> live, List<Line> sample) {
			this.live = live;
			this.sample = sample;
		}

		private List<Line> lines(Minecraft mc, boolean preview) {
			if (preview || mc.player == null || mc.level == null) {
				return sample;
			}
			if (cachedFrame == Stats.frameId) {
				return cached;
			}
			try {
				cached = live.apply(mc);
				if (cached == null) {
					cached = List.of();
				}
				errors = 0;
			} catch (Throwable t) {
				cached = List.of();
				if (++errors == 1) {
					Safe.report("HUD module", t);
				}
			}
			cachedFrame = Stats.frameId;
			return cached;
		}

		@Override
		public boolean visible(Minecraft mc, Module m) {
			return mc.player != null && !lines(mc, false).isEmpty();
		}

		private static int lineWidth(Font font, Line l) {
			int w = font.width(l.label()) + (l.label().isEmpty() ? 0 : 6) + font.width(l.value());
			return l.big() ? (int) (font.width(l.value()) * 1.5F) : w;
		}

		private static int lineHeight(Line l) {
			return (l.big() ? 15 : 11) + (l.bar() >= 0 ? 4 : 0);
		}

		@Override
		public int width(Font font, Module m, boolean preview) {
			int w = 0;
			for (Line l : lines(Minecraft.getInstance(), preview)) {
				w = Math.max(w, lineWidth(font, l));
			}
			return w + 12;
		}

		@Override
		public int height(Font font, Module m, boolean preview) {
			int h = 5;
			for (Line l : lines(Minecraft.getInstance(), preview)) {
				h += lineHeight(l);
			}
			return h;
		}

		@Override
		public void draw(GuiGraphicsExtractor g, Font font, Module m, int x, int y, boolean preview) {
			int yy = y + 3;
			int fullW = width(font, m, preview) - 12;
			for (Line l : lines(Minecraft.getInstance(), preview)) {
				int xx = x + 6;
				if (l.big()) {
					Gfx.scaledText(g, font, l.value(), xx, yy, l.color(), 1.5F);
				} else {
					if (!l.label().isEmpty()) {
						Gfx.text(g, font, l.label(), xx, yy, Gfx.MUTED);
						xx += font.width(l.label()) + 6;
					}
					Gfx.text(g, font, l.value(), xx, yy, l.color());
				}
				yy += l.big() ? 15 : 11;
				if (l.bar() >= 0) {
					Gfx.round(g, x + 6, yy, x + 6 + fullW, yy + 2, 1, Gfx.TRACK);
					Gfx.round(g, x + 6, yy, x + 6 + Math.max(2, Math.round(fullW * l.bar())), yy + 2, 1, l.color());
					yy += 4;
				}
			}
		}
	}

	// ------------------------------------------------------------ helpers

	private static int auto = 0;

	private static Module h(String id, String name, String desc, String cat, Item icon, boolean on, double fx, double fy,
			Function<Minecraft, List<Line>> live, List<Line> sample, Setting... s) {
		if (fx < 0) {
			int i = auto++;
			fx = 0.01 + 0.165 * (i / 11);
			fy = 0.03 + 0.078 * (i % 11);
		}
		return new Module(id, name, desc, cat, icon, on, new LineHud(live, sample), fx, fy, s);
	}

	private static Module t2(String id, String name, String desc, String cat, Item icon, Setting... s) {
		return new Module(id, name, desc, cat, icon, false, null, 0, 0, s);
	}

	private static Module t(String id, String name, String desc, Item icon, Setting... s) {
		return new Module(id, name, desc, UTILITY, icon, false, null, 0, 0, s);
	}

	private static List<Line> one(String label, String value, int color) {
		return List.of(new Line(label, value, color));
	}

	private static List<Line> none() {
		return List.of();
	}

	private static int good(double v, double ok, double bad) {
		return v >= ok ? GREEN : v >= bad ? YELLOW : RED;
	}

	private static int countItem(LocalPlayer p, Item item) {
		int n = 0;
		for (int i = 0; i < 36; i++) {
			ItemStack st = p.getInventory().getItem(i);
			if (st.is(item)) {
				n += st.getCount();
			}
		}
		ItemStack off = p.getOffhandItem();
		if (off.is(item)) {
			n += off.getCount();
		}
		return n;
	}

	private static Module counter(String id, String name, Item item, int warnBelow) {
		return h(id, name, "How many " + name.toLowerCase().replace(" count", "") + " you carry.", PLAYER, item, false, -1, -1,
				mc -> {
					int n = countItem(mc.player, item);
					return one(name.replace(" Count", ""), String.valueOf(n), n >= warnBelow ? GREEN : n > 0 ? YELLOW : RED);
				}, one(name.replace(" Count", ""), "4", GREEN));
	}

	private static String heading(float yaw) {
		String[] n = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
		int i = (int) Math.floor((((yaw % 360) + 360) % 360 + 22.5) / 45.0) % 8;
		return n[i];
	}

	private static String hms(long ms) {
		long s = ms / 1000;
		return String.format("%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
	}

	// ------------------------------------------------------------------ Info

	public static final Module WATERMARK = h("watermark", "Watermark", "Shows the Emerald Client name on screen.",
			INFO, Items.EMERALD, true, 0.45, 0.012,
			mc -> one("", "EMERALD CLIENT", Gfx.ACCENT2), one("", "EMERALD CLIENT", Gfx.ACCENT2));

	public static final Module FPS = h("fps", "FPS", "Frames per second, coloured by how smooth it is.",
			INFO, Items.CLOCK, true, 0.01, 0.02,
			mc -> one("FPS", String.valueOf(Stats.fps), good(Stats.fps, 60, 30)), one("FPS", "240", GREEN));

	public static final Module FRAME_TIME = h("frame_time", "Frame Time", "How long each frame takes, in milliseconds.",
			INFO, Items.REPEATER, false, -1, -1,
			mc -> one("Frame", String.format("%.1f ms", Stats.frameMs), Stats.frameMs < 16.7F ? GREEN : Stats.frameMs < 33.4F ? YELLOW : RED),
			one("Frame", "4.2 ms", GREEN));

	public static final Module FPS_STATS = h("fps_stats", "FPS Stats", "Lowest, average and highest FPS since you joined.",
			INFO, Items.COMPARATOR, false, -1, -1,
			mc -> {
				if (Stats.fpsSamples == 0) {
					return none();
				}
				return List.of(new Line("Min", String.valueOf(Stats.fpsMin), YELLOW),
						new Line("Avg", String.valueOf(Stats.fpsSum / Stats.fpsSamples), GREEN),
						new Line("Max", String.valueOf(Stats.fpsMax), WHITE));
			}, List.of(new Line("Min", "88", YELLOW), new Line("Avg", "190", GREEN), new Line("Max", "260", WHITE)));

	public static final Module PING = h("ping", "Ping", "Your latency to the server.",
			INFO, Items.COMPASS, false, -1, -1,
			mc -> {
				ClientPacketListener conn = mc.getConnection();
				int ms = 0;
				if (conn != null && conn.getPlayerInfo(mc.player.getUUID()) != null) {
					ms = conn.getPlayerInfo(mc.player.getUUID()).getLatency();
				}
				return one("Ping", ms + " ms", ms <= 80 ? GREEN : ms <= 160 ? YELLOW : RED);
			}, one("Ping", "32 ms", GREEN));

	public static final Module CPS = h("cps", "CPS", "Clicks per second (left | right).",
			INFO, Items.IRON_SWORD, true, 0.01, 0.08,
			mc -> one("CPS", Stats.cpsLeft() + " | " + Stats.cpsRight(), WHITE), one("CPS", "9 | 3", WHITE));

	public static final Module SPEED = h("speed", "Speed", "How fast you move, in blocks per second.",
			INFO, Items.FEATHER, false, -1, -1,
			mc -> one("Speed", String.format("%.1f b/s", Stats.speed), WHITE), one("Speed", "5.6 b/s", WHITE));

	public static final Module MEMORY = h("memory", "Memory", "Java memory in use.",
			INFO, Items.REDSTONE, false, -1, -1,
			mc -> {
				Runtime rt = Runtime.getRuntime();
				long used = (rt.totalMemory() - rt.freeMemory()) >> 20;
				long max = rt.maxMemory() >> 20;
				int color = used * 10 > max * 9 ? RED : used * 10 > max * 7 ? YELLOW : GREEN;
				return one("RAM", used + " / " + max + " MB", color);
			}, one("RAM", "2048 / 8192 MB", GREEN));

	public static final Module CLOCK = h("clock", "Clock", "Your real-world time.",
			INFO, Items.CLOCK, false, -1, -1,
			mc -> one("", LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), WHITE), one("", "12:34:56", WHITE));

	public static final Module DATE = h("date", "Date", "Today's date.",
			INFO, Items.PAPER, false, -1, -1,
			mc -> one("", LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")), WHITE), one("", "20/10/2026", WHITE));

	public static final Module SESSION = h("session", "Session Timer", "How long you have been playing this session.",
			INFO, Items.SAND, false, -1, -1,
			mc -> one("Playing", hms(System.currentTimeMillis() - Stats.SESSION_START), WHITE), one("Playing", "01:12:09", WHITE));

	public static final Module COORDS = h("coords", "Coordinates", "Your X, Y, Z position and facing direction.",
			INFO, Items.MAP, true, 0.01, 0.14,
			mc -> {
				LocalPlayer p = mc.player;
				return List.of(new Line("XYZ", String.format("%.1f  %.1f  %.1f", p.getX(), p.getY(), p.getZ()), WHITE),
						new Line("Facing", heading(p.getYRot()), GREEN));
			}, List.of(new Line("XYZ", "128.5  64.0  -302.2", WHITE), new Line("Facing", "N", GREEN)));

	public static final Module NETHER = h("nether", "Nether Coords", "Your position converted between Overworld and Nether (x8).",
			INFO, Items.NETHERRACK, false, -1, -1,
			mc -> List.of(new Line("Nether", String.format("%.0f  %.0f", mc.player.getX() / 8, mc.player.getZ() / 8), YELLOW),
					new Line("Overworld", String.format("%.0f  %.0f", mc.player.getX() * 8, mc.player.getZ() * 8), GREEN)),
			List.of(new Line("Nether", "16  -37", YELLOW), new Line("Overworld", "1024  -2416", GREEN)));

	public static final Module CHUNK = h("chunk", "Chunk", "The chunk you are standing in.",
			INFO, Items.GRASS_BLOCK, false, -1, -1,
			mc -> one("Chunk", (mc.player.getBlockX() >> 4) + ", " + (mc.player.getBlockZ() >> 4), WHITE), one("Chunk", "8, -19", WHITE));

	public static final Module COMPASS_M = h("compass", "Direction", "Compass heading with yaw and pitch.",
			INFO, Items.RECOVERY_COMPASS, false, -1, -1,
			mc -> List.of(new Line("Heading", heading(mc.player.getYRot()), GREEN),
					new Line("Yaw", String.format("%.0f", ((mc.player.getYRot() % 360) + 360) % 360), WHITE),
					new Line("Pitch", String.format("%.0f", mc.player.getXRot()), WHITE)),
			List.of(new Line("Heading", "NE", GREEN), new Line("Yaw", "225", WHITE), new Line("Pitch", "12", WHITE)));

	public static final Module LIGHT = h("light", "Light Level", "Light level where you stand (monsters can spawn at 0).",
			INFO, Items.TORCH, false, -1, -1,
			mc -> {
				int l = mc.level.getMaxLocalRawBrightness(mc.player.blockPosition());
				return one("Light", String.valueOf(l), l >= 8 ? GREEN : l >= 1 ? YELLOW : RED);
			}, one("Light", "15", GREEN));

	public static final Module LOOKING_AT = h("looking_at", "Looking At", "Name of the block under your crosshair.",
			INFO, Items.SPYGLASS, false, -1, -1,
			mc -> {
				if (mc.hitResult instanceof BlockHitResult b && b.getType() == HitResult.Type.BLOCK) {
					return one("Block", mc.level.getBlockState(b.getBlockPos()).getBlock().getName().getString(), WHITE);
				}
				return none();
			}, one("Block", "Oak Log", WHITE));

	public static final Module SERVER = h("server", "Server IP", "The server you are playing on.",
			INFO, Items.ENDER_EYE, false, -1, -1,
			mc -> one("Server", mc.getCurrentServer() == null ? "Singleplayer" : mc.getCurrentServer().ip, WHITE),
			one("Server", "play.example.net", WHITE));

	public static final Module ONLINE = h("online", "Players Online", "How many players are on the server.",
			INFO, Items.PLAYER_HEAD, false, -1, -1,
			mc -> one("Online", String.valueOf(mc.getConnection() == null ? 1 : mc.getConnection().getOnlinePlayers().size()), WHITE),
			one("Online", "42", WHITE));

	public static final Module NEARBY = h("nearby", "Nearby Players", "Counts other players close to you.",
			INFO, Items.TARGET, false, -1, -1,
			mc -> {
				int r = (int) NearbyRadius();
				int n = 0;
				for (var other : mc.level.players()) {
					if (other != mc.player && other.distanceTo(mc.player) <= r) {
						n++;
					}
				}
				return one("Nearby", String.valueOf(n), n == 0 ? GREEN : RED);
			}, one("Nearby", "2", RED),
			Setting.number("radius", "Radius", 64, 16, 128, 8, " blocks"));

	private static double NearbyRadius() {
		return NEARBY == null ? 64 : NEARBY.num("radius");
	}

	// ---------------------------------------------------------------- Player

	private static final int KEY = 20;
	private static final int GAP = 2;

	private static final Module.Hud KEYSTROKES_HUD = new Module.Hud() {
		@Override
		public boolean visible(Minecraft mc, Module m) {
			return mc.player != null;
		}

		@Override
		public int width(Font font, Module m, boolean preview) {
			return KEY * 3 + GAP * 2 + 8;
		}

		@Override
		public int height(Font font, Module m, boolean preview) {
			return KEY * 3 + GAP * 2 + 8 + (m.flag("mouse") ? 0 : -(KEY + GAP));
		}

		private void key(GuiGraphicsExtractor g, Font font, int x, int y, int w, String label, boolean down) {
			Gfx.round(g, x, y, x + w, y + KEY, 4, down ? Gfx.withAlpha(GREEN, 230) : 0x99101A14);
			Gfx.centered(g, font, label, x + w / 2, y + (KEY - 8) / 2, down ? 0xFF06110B : Gfx.TEXT);
		}

		@Override
		public void draw(GuiGraphicsExtractor g, Font font, Module m, int x, int y, boolean preview) {
			Minecraft mc = Minecraft.getInstance();
			boolean w = preview || mc.options.keyUp.isDown();
			boolean a = !preview && mc.options.keyLeft.isDown();
			boolean s = !preview && mc.options.keyDown.isDown();
			boolean d = !preview && mc.options.keyRight.isDown();
			int x0 = x + 4;
			int y0 = y + 4;
			key(g, font, x0 + KEY + GAP, y0, KEY, "W", w);
			key(g, font, x0, y0 + KEY + GAP, KEY, "A", a);
			key(g, font, x0 + KEY + GAP, y0 + KEY + GAP, KEY, "S", s);
			key(g, font, x0 + (KEY + GAP) * 2, y0 + KEY + GAP, KEY, "D", d);
			if (m.flag("mouse")) {
				int bw = (KEY * 3 + GAP * 2 - GAP) / 2;
				boolean l = !preview && mc.options.keyAttack.isDown();
				boolean r = !preview && mc.options.keyUse.isDown();
				key(g, font, x0, y0 + (KEY + GAP) * 2, bw, "LMB " + (preview ? 9 : Stats.cpsLeft()), l);
				key(g, font, x0 + bw + GAP, y0 + (KEY + GAP) * 2, bw, "RMB " + (preview ? 3 : Stats.cpsRight()), r);
			}
		}
	};

	public static final Module KEYSTROKES = new Module("keystrokes", "Keystrokes", "Shows W A S D and mouse buttons as you press them.",
			PLAYER, Items.OAK_BUTTON, true, KEYSTROKES_HUD, 0.01, 0.55,
			Setting.toggle("mouse", "Show mouse buttons", true));

	private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

	private static final Module.Hud ARMOR_HUD = new Module.Hud() {
		private ItemStack stack(Minecraft mc, int i, boolean preview) {
			if (preview || mc.player == null) {
				return new ItemStack(new Item[] {
						Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS}[i]);
			}
			return mc.player.getItemBySlot(ARMOR[i]);
		}

		@Override
		public boolean visible(Minecraft mc, Module m) {
			if (mc.player == null) {
				return false;
			}
			for (int i = 0; i < 4; i++) {
				if (!stack(mc, i, false).isEmpty()) {
					return true;
				}
			}
			return false;
		}

		@Override
		public int width(Font font, Module m, boolean preview) {
			return 64;
		}

		@Override
		public int height(Font font, Module m, boolean preview) {
			return 4 * 18 + 6;
		}

		@Override
		public void draw(GuiGraphicsExtractor g, Font font, Module m, int x, int y, boolean preview) {
			Minecraft mc = Minecraft.getInstance();
			int yy = y + 3;
			for (int i = 0; i < 4; i++) {
				ItemStack st = stack(mc, i, preview);
				if (!st.isEmpty()) {
					g.fakeItem(st, x + 4, yy);
					if (st.getMaxDamage() > 0) {
						int left = st.getMaxDamage() - st.getDamageValue();
						float f = left / (float) st.getMaxDamage();
						Gfx.text(g, font, String.valueOf(left), x + 24, yy + 4, f > 0.5F ? GREEN : f > 0.2F ? YELLOW : RED);
					}
				}
				yy += 18;
			}
		}
	};

	public static final Module ARMOR_STATUS = new Module("armor", "Armor Status", "Your armor pieces with their durability left.",
			PLAYER, Items.DIAMOND_CHESTPLATE, true, ARMOR_HUD, 0.88, 0.45);

	public static final Module POTIONS = h("potions", "Potion Status", "Active potion effects with time left.",
			PLAYER, Items.POTION, false, 0.88, 0.05,
			mc -> {
				List<Line> out = new ArrayList<>();
				Collection<MobEffectInstance> effects = mc.player.getActiveEffects();
				for (MobEffectInstance e : effects) {
					String name = Component.translatable(e.getDescriptionId()).getString();
					String time;
					if (e.isInfiniteDuration()) {
						time = "inf";
					} else {
						int s = e.getDuration() / 20;
						time = (s / 60) + ":" + String.format("%02d", s % 60);
					}
					out.add(new Line(name + (e.getAmplifier() > 0 ? " " + (e.getAmplifier() + 1) : ""), time,
							e.getDuration() < 200 && !e.isInfiniteDuration() ? RED : WHITE));
				}
				return out;
			}, List.of(new Line("Speed 2", "4:12", WHITE), new Line("Strength", "0:08", RED)));

	public static final Module SPRINT = h("sprint", "Sprint Status", "Shows whether you are sprinting or sneaking.",
			PLAYER, Items.LEATHER_BOOTS, false, -1, -1,
			mc -> {
				LocalPlayer p = mc.player;
				if (p.isShiftKeyDown()) {
					return one("", "Sneaking", YELLOW);
				}
				return p.isSprinting() ? one("", "Sprinting", GREEN) : one("", "Walking", Gfx.MUTED);
			}, one("", "Sprinting", GREEN));

	public static final Module HEALTH = h("health", "Health", "Your hearts as a number.",
			PLAYER, Items.APPLE, false, -1, -1,
			mc -> {
				LocalPlayer p = mc.player;
				float hp = p.getHealth();
				String extra = p.getAbsorptionAmount() > 0 ? String.format(" +%.1f", p.getAbsorptionAmount()) : "";
				return one("HP", String.format("%.1f / %.0f", hp, p.getMaxHealth()) + extra, good(hp / p.getMaxHealth(), 0.6, 0.3));
			}, one("HP", "20.0 / 20", GREEN));

	public static final Module HUNGER = h("hunger", "Hunger", "Food level.",
			PLAYER, Items.COOKED_BEEF, false, -1, -1,
			mc -> one("Food", mc.player.getFoodData().getFoodLevel() + " / 20", good(mc.player.getFoodData().getFoodLevel(), 14, 7)),
			one("Food", "20 / 20", GREEN));

	public static final Module SATURATION = h("saturation", "Saturation", "Hidden food saturation (how long until you get hungry).",
			PLAYER, Items.GOLDEN_CARROT, false, -1, -1,
			mc -> one("Saturation", String.format("%.1f", mc.player.getFoodData().getSaturationLevel()), WHITE),
			one("Saturation", "5.0", WHITE));

	public static final Module XP = h("xp", "XP Level", "Your experience level.",
			PLAYER, Items.EXPERIENCE_BOTTLE, false, -1, -1,
			mc -> one("XP", mc.player.experienceLevel + String.format("  (%d%%)", Math.round(mc.player.experienceProgress * 100)), GREEN),
			one("XP", "30  (40%)", GREEN));

	public static final Module AIR = h("air", "Air Bubbles", "Breath left, only while underwater.",
			PLAYER, Items.TURTLE_HELMET, false, -1, -1,
			mc -> {
				int air = mc.player.getAirSupply();
				int max = mc.player.getMaxAirSupply();
				if (air >= max) {
					return none();
				}
				return one("Air", String.format("%.1f s", Math.max(0, air) / 20.0), good(air, max * 0.5, max * 0.2));
			}, one("Air", "9.5 s", YELLOW));

	public static final Module ARMOR_POINTS = h("armor_points", "Armor Points", "Total armor value.",
			PLAYER, Items.IRON_CHESTPLATE, false, -1, -1,
			mc -> one("Armor", String.valueOf(mc.player.getArmorValue()), WHITE), one("Armor", "20", WHITE));

	public static final Module HELD = h("held", "Held Item", "Name and durability of the item in your hand.",
			PLAYER, Items.DIAMOND_PICKAXE, false, -1, -1,
			mc -> {
				ItemStack st = mc.player.getMainHandItem();
				if (st.isEmpty()) {
					return none();
				}
				List<Line> out = new ArrayList<>();
				out.add(new Line("", st.getHoverName().getString(), WHITE));
				if (st.getMaxDamage() > 0) {
					int left = st.getMaxDamage() - st.getDamageValue();
					out.add(new Line("Durability", left + " / " + st.getMaxDamage(), good(left / (double) st.getMaxDamage(), 0.5, 0.2)));
				}
				return out;
			}, List.of(new Line("", "Diamond Pickaxe", WHITE), new Line("Durability", "1200 / 1561", GREEN)));

	public static final Module OFFHAND = h("offhand", "Offhand Item", "What you hold in your offhand.",
			PLAYER, Items.SHIELD, false, -1, -1,
			mc -> {
				ItemStack st = mc.player.getOffhandItem();
				if (st.isEmpty()) {
					return none();
				}
				return one("Offhand", st.getHoverName().getString() + (st.getCount() > 1 ? " x" + st.getCount() : ""), WHITE);
			}, one("Offhand", "Totem of Undying x3", WHITE));

	public static final Module TOTEMS = counter("totems", "Totem Count", Items.TOTEM_OF_UNDYING, 2);
	public static final Module GAPPLES = counter("gapples", "Gapple Count", Items.GOLDEN_APPLE, 4);
	public static final Module PEARLS = counter("pearls", "Pearl Count", Items.ENDER_PEARL, 3);
	public static final Module ARROWS = counter("arrows", "Arrow Count", Items.ARROW, 16);
	public static final Module CRYSTALS = counter("crystals", "Crystal Count", Items.END_CRYSTAL, 8);
	public static final Module SPLASH = counter("splash", "Splash Count", Items.SPLASH_POTION, 4);

	public static final Module LOW_HEALTH = h("low_health", "Low Health Warning", "Big red warning when your hearts run low.",
			PLAYER, Items.REDSTONE_TORCH, false, 0.43, 0.30,
			mc -> mc.player.getHealth() / 2.0F <= LOW_HEALTH_AT() ? one("", "LOW HEALTH", (System.currentTimeMillis() / 300) % 2 == 0 ? RED : YELLOW) : none(),
			one("", "LOW HEALTH", RED),
			Setting.number("hearts", "Warn at hearts", 4, 1, 9.5, 0.5, ""));

	private static double LOW_HEALTH_AT() {
		return LOW_HEALTH == null ? 4 : LOW_HEALTH.num("hearts");
	}

	public static final Module DURA_WARN = h("dura_warn", "Durability Warning", "Warns when armor or your held tool is almost broken.",
			PLAYER, Items.ANVIL, false, 0.43, 0.36,
			mc -> {
				List<Line> out = new ArrayList<>();
				String[] names = {"Helmet", "Chestplate", "Leggings", "Boots"};
				for (int i = 0; i < 4; i++) {
					ItemStack st = mc.player.getItemBySlot(ARMOR[i]);
					if (st.getMaxDamage() > 0) {
						int pct = (st.getMaxDamage() - st.getDamageValue()) * 100 / st.getMaxDamage();
						if (pct <= DURA_AT()) {
							out.add(new Line(names[i], pct + "%", RED));
						}
					}
				}
				return out;
			}, List.of(new Line("Boots", "9%", RED)),
			Setting.number("pct", "Warn below", 15, 5, 50, 5, "%"));

	private static double DURA_AT() {
		return DURA_WARN == null ? 15 : DURA_WARN.num("pct");
	}

	// ---------------------------------------------------------------- Combat

	public static final Module TARGET = h("target", "Target HUD", "Name and health of whoever you are fighting.",
			COMBAT, Items.DIAMOND_SWORD, false, -1, -1,
			mc -> {
				LivingEntity t = Stats.target;
				if (t == null || !t.isAlive() || System.currentTimeMillis() - Stats.targetMs > 2500) {
					return none();
				}
				float hp = t.getHealth();
				return List.of(new Line("", t.getName().getString(), WHITE),
						new Line("HP", String.format("%.1f / %.0f", hp, t.getMaxHealth()), good(hp / t.getMaxHealth(), 0.6, 0.3)),
						new Line("Dist", String.format("%.2f", Math.sqrt(t.getBoundingBox().distanceToSqr(mc.player.getEyePosition()))), WHITE));
			}, List.of(new Line("", "Steve", WHITE), new Line("HP", "14.0 / 20", YELLOW), new Line("Dist", "2.81", WHITE)));

	public static final Module COMBO = h("combo", "Combo Counter", "Hits in a row before the enemy hits you back.",
			COMBAT, Items.BLAZE_ROD, false, -1, -1,
			mc -> one("Combo", String.valueOf(Stats.combo), Stats.combo >= 3 ? GREEN : WHITE), one("Combo", "4", GREEN));

	public static final Module REACH = h("reach", "Reach Display", "Distance of your last hit.",
			COMBAT, Items.STICK, false, -1, -1,
			mc -> one("Reach", Stats.lastReach < 0 || System.currentTimeMillis() - Stats.lastHitMs > 6000
					? "-" : String.format("%.2f", Stats.lastReach), Stats.lastReach > 3.0 ? YELLOW : WHITE),
			one("Reach", "2.84", WHITE));

	public static final Module HITBOX = h("hitbox", "Hitbox Info", "Size of the hitbox under your crosshair and how far its edge is.",
			COMBAT, Items.ARMOR_STAND, false, -1, -1,
			mc -> {
				if (mc.hitResult instanceof net.minecraft.world.phys.EntityHitResult eh) {
					var e = eh.getEntity();
					double d = Math.sqrt(e.getBoundingBox().distanceToSqr(mc.player.getEyePosition()));
					return List.of(new Line("Hitbox", String.format("%.2f x %.2f", e.getBbWidth(), e.getBbHeight()), WHITE),
							new Line("Edge dist", String.format("%.2f", d), d <= 3.0 ? GREEN : YELLOW));
				}
				return none();
			}, List.of(new Line("Hitbox", "0.60 x 1.80", WHITE), new Line("Edge dist", "2.40", GREEN)));

	public static final Module CLOSEST = h("closest", "Closest Player", "The nearest other player and how far away they are.",
			COMBAT, Items.SKELETON_SKULL, false, -1, -1,
			mc -> {
				var best = (net.minecraft.world.entity.player.Player) null;
				for (var other : mc.level.players()) {
					if (other != mc.player && (best == null || other.distanceTo(mc.player) < best.distanceTo(mc.player))) {
						best = other;
					}
				}
				if (best == null) {
					return none();
				}
				return one(best.getName().getString(), String.format("%.1f m", best.distanceTo(mc.player)), best.distanceTo(mc.player) < 8 ? RED : WHITE);
			}, one("Alex", "12.3 m", WHITE));

	public static final Module CHARGE = h("charge", "Attack Charge", "How charged your next hit is (100% = full damage).",
			COMBAT, Items.CLOCK, false, -1, -1,
			mc -> {
				int pct = Math.round(mc.player.getAttackStrengthScale(0.0F) * 100);
				return one("Charge", pct + "%", pct >= 100 ? GREEN : pct >= 60 ? YELLOW : RED);
			}, one("Charge", "100%", GREEN));


	// ----------------------------------------------------- PvP assist (merged from PvP Helper)

	private static final int ORANGE = 0xFFFB923C;

	public static final Module REACH_ASSIST = h("reach_assist", "Reach Assist", "Distance to the enemy's hitbox vs your reach, and the reach of your last hit.",
			COMBAT, Items.SPYGLASS, false, -1, -1,
			mc -> {
				List<Line> out = new ArrayList<>();
				LivingEntity target = Targeting.find(mc, mc.player);
				double reach = REACH_ASSIST_MAX();
				if (target != null) {
					double d = Targeting.distanceToHitbox(mc.player, target);
					int color = d <= reach ? GREEN : (d <= reach + 1.5 ? YELLOW : Gfx.MUTED);
					out.add(Line.withBar("Reach", String.format("%.2f / %.1f", d, reach), color, (float) (reach / Math.max(d, 0.01))));
				}
				if (Stats.lastReach >= 0 && System.currentTimeMillis() - Stats.lastHitMs < 6000) {
					out.add(new Line("Last hit", String.format("%.2f", Stats.lastReach), WHITE));
				}
				return out;
			}, List.of(Line.withBar("Reach", "2.84 / 3.0", GREEN, 1.0F), new Line("Last hit", "2.91", WHITE)),
			Setting.number("reach", "Your max reach", 3.0, 2.0, 6.0, 0.1, ""));

	private static double REACH_ASSIST_MAX() {
		return REACH_ASSIST == null ? 3.0 : REACH_ASSIST.num("reach");
	}

	public static final Module HIT_TIMING = h("hit_timing", "Hit Timing", "Tells you when to hit: HIT NOW / WAIT / CLOSE IN, plus damage and hits to kill.",
			COMBAT, Items.CLOCK, false, -1, -1, Modules::hitTimingLines,
			List.of(Line.headline("HIT NOW!  (CRIT)", GREEN), Line.withBar("Cooldown", "100%", GREEN, 1.0F), new Line("", "Dmg ~7.5  |  HP 20.0  |  3 hits", WHITE)),
			Setting.number("hit_at", "Hit at cooldown", 90, 50, 100, 5, "%"));

	public static final Module AUTO_HIT = t2("auto_hit", "Auto Hit", "Attacks for you at the perfect moment when your crosshair is on an enemy in reach.",
			COMBAT, Items.DIAMOND_SWORD,
			Setting.toggle("need_key", "Only while holding attack", true),
			Setting.toggle("players_only", "Players only", true));

	public static final Module CRYSTAL_OPTIMIZER = t2("crystal_optimizer", "Crystal Optimizer", "Crystals you hit vanish on your screen instantly (less ping delay). Many servers ban this.",
			COMBAT, Items.END_CRYSTAL);

	public static final Module TOTEM_WARNING = h("totem_warning", "Totem Warning", "Flashing warning when your health gets low and no totem is in your offhand.",
			COMBAT, Items.BELL, false, 0.40, 0.16, Modules::totemWarningLines,
			List.of(Line.headline("EQUIP TOTEM  -  press F", RED), Line.withBar("", "3.5 hearts left  |  2 totems", ORANGE, 0.35F)),
			Setting.number("warn_at", "Warn at hearts", 4.0, 1.0, 9.5, 0.5, ""));

	public static final Module TOTEM_HELPER = t2("totem_helper", "Totem Helper", "When the warning shows, press F and it grabs a totem from your hotbar into your offhand.",
			COMBAT, Items.HOPPER,
			Setting.toggle("auto", "Equip automatically (no key)", false));

	private static List<Line> hitTimingLines(Minecraft mc) {
		LocalPlayer player = mc.player;
		List<Line> out = new ArrayList<>();
		LivingEntity target = Targeting.find(mc, player);
		if (target == null) {
			return out;
		}
		double reach = REACH_ASSIST_MAX();
		float fullCharge = (float) (HIT_TIMING.num("hit_at") / 100.0);
		double distance = Targeting.distanceToHitbox(player, target);
		float charge = player.getAttackStrengthScale(0.0F);
		boolean falling = !player.onGround() && player.fallDistance > 0.0;
		boolean crit = falling && charge >= fullCharge;

		String advice;
		int color;
		if (distance > reach + 1.5) {
			advice = "FAR";
			color = Gfx.MUTED;
		} else if (distance > reach) {
			advice = String.format("CLOSE IN  (%.2f to reach)", distance - reach);
			color = YELLOW;
		} else if (charge < fullCharge) {
			advice = String.format("WAIT  cooldown %d%%", Math.round(charge * 100.0F));
			color = ORANGE;
		} else if (target.hurtTime > 5) {
			advice = "WAIT  target just got hit";
			color = ORANGE;
		} else {
			advice = crit ? "HIT NOW!  (CRIT)" : "HIT NOW!";
			color = GREEN;
		}
		out.add(Line.headline(advice, color));
		out.add(Line.withBar("Cooldown", Math.round(charge * 100.0F) + "%", charge >= fullCharge ? GREEN : ORANGE, charge));

		double base = player.getAttributeValue(Attributes.ATTACK_DAMAGE);
		double scaled = base * (0.2 + charge * charge * 0.8);
		if (crit) {
			scaled *= 1.5;
		}
		double armor = target.getArmorValue();
		double toughness = target.getAttributeValue(Attributes.ARMOR_TOUGHNESS);
		double eff = Mth.clamp(Math.max(armor / 5.0, armor - scaled / (2.0 + toughness / 4.0)), 0.0, 20.0);
		double damage = scaled * (1.0 - eff / 25.0);
		float health = target.getHealth() + target.getAbsorptionAmount();
		int hits = damage > 0.01 ? (int) Math.ceil(health / damage) : 99;
		out.add(new Line("", String.format("Dmg ~%.1f  |  HP %.1f  |  %d hit%s", damage, health, hits, hits == 1 ? "" : "s"),
				hits <= 2 ? RED : WHITE));
		return out;
	}

	private static List<Line> totemWarningLines(Minecraft mc) {
		LocalPlayer player = mc.player;
		float hp = player.getHealth();
		float hearts = hp / 2.0F;
		if (hp <= 0 || hearts > TOTEM_WARNING.num("warn_at")) {
			return List.of();
		}
		boolean flash = (System.currentTimeMillis() / 250) % 2 == 0;
		int total = Automation.countTotems(player);
		boolean offhandTotem = Automation.offhandHasTotem(player);
		boolean helper = TOTEM_HELPER.enabled;
		boolean inHotbar = Automation.hotbarTotemSlot(player) >= 0;
		boolean auto = helper && TOTEM_HELPER.flag("auto");

		List<Line> out = new ArrayList<>();
		if (total == 0) {
			out.add(Line.headline("NO TOTEMS LEFT!", flash ? RED : ORANGE));
		} else if (offhandTotem) {
			out.add(Line.headline("Low health  -  totem ready", YELLOW));
		} else if (!inHotbar) {
			out.add(Line.headline("MOVE A TOTEM TO YOUR HOTBAR!", flash ? RED : ORANGE));
		} else if (helper && auto) {
			out.add(Line.headline("EQUIPPING TOTEM...", flash ? RED : ORANGE));
		} else if (helper) {
			out.add(Line.headline("EQUIP TOTEM  -  press F", flash ? RED : ORANGE));
		} else {
			out.add(Line.headline("EQUIP TOTEM NOW!", flash ? RED : ORANGE));
		}
		out.add(Line.withBar("", String.format("%.1f hearts left  |  %d totem%s", hearts, total, total == 1 ? "" : "s"), ORANGE, hp / 20.0F));
		return out;
	}

	// --------------------------------------------------------------- Utility

	public static final Module FULLBRIGHT = t("fullbright", "Fullbright", "Maximum brightness setting, caves are easier to see.", Items.GLOWSTONE);
	public static final Module NIGHT_VISION = t("night_vision", "Night Vision", "See clearly at night and in caves (client-side night vision effect).", Items.GOLDEN_CARROT);
	public static final Module ZOOM = t("zoom", "Zoom", "Hold the Zoom key (C) to zoom in like a spyglass.", Items.SPYGLASS,
			Setting.number("fov", "Zoom FOV", 30, 30, 70, 5, ""));
	public static final Module FOV_CHANGER = t("fov_changer", "FOV Changer", "Set your field of view with a slider.", Items.ENDER_EYE,
			Setting.number("fov", "FOV", 100, 30, 110, 1, ""));
	public static final Module NO_BOB = t("no_bob", "No View Bobbing", "Stops the screen shaking while you walk.", Items.LEAD);
	public static final Module NO_CLOUDS = t("no_clouds", "Clouds Off", "Hides clouds for a little extra FPS.", Items.WHITE_WOOL);
	public static final Module ALWAYS_SPRINT = t("always_sprint", "Always Sprint", "Sprint automatically while you hold forward.", Items.GOLDEN_BOOTS);
	public static final Module AUTO_WALK = t("auto_walk", "Auto Walk", "Walks forward by itself. Turn it off to stop.", Items.IRON_BOOTS);
	public static final Module AUTO_RESPAWN = t("auto_respawn", "Auto Respawn", "Respawns for you as soon as you die.", Items.TOTEM_OF_UNDYING,
			Setting.number("delay", "Delay", 0.5, 0, 3, 0.5, " s"));
	public static final Module ANTI_AFK = t("anti_afk", "Anti AFK", "Jumps now and then so you do not get kicked for idling.", Items.CLOCK,
			Setting.number("secs", "Every", 30, 10, 120, 5, " s"));
	public static final Module SNAP_TAP = t("snap_tap", "Snap Tap",
			"Like a magnetic keyboard: hold A then press D and you go right at once, no stopping. Letting go of D goes back to A.",
			Items.IRON_NUGGET,
			Setting.toggle("strafe", "A / D", true),
			Setting.toggle("forward", "W / S", false));
	public static final Module UNLIMITED_FPS = t("unlimited_fps", "Unlimited FPS", "Removes the FPS cap.", Items.LIGHTNING_ROD);
	public static final Module NO_VSYNC = t("no_vsync", "VSync Off", "Turns VSync off for lower input delay.", Items.COMPARATOR);
	public static final Module THEME = new Module("menu_theme", "Themed Menus", "Green Emerald background on the world list and the server list.",
			UTILITY, Items.EMERALD, true, null, 0, 0);
	public static final Module TITLE = new Module("title_screen", "Custom Main Menu", "Replaces the Minecraft title screen with the Emerald one.",
			UTILITY, Items.EMERALD_BLOCK, true, null, 0, 0);

	// ----------------------------------------------------------- Performance

	public static final Module FPS_BOOST = new Module("fps_boost", "FPS Boost",
			"One switch for more FPS: lowers distances and turns off costly extras. Your old settings come back when you turn it off.",
			PERF, Items.SUGAR, false, null, 0, 0,
			Setting.number("render", "Max render distance", 8, 2, 32, 1, " chunks"),
			Setting.number("sim", "Max simulation distance", 6, 5, 32, 1, " chunks"),
			Setting.toggle("entities", "Fewer far entities", true),
			Setting.toggle("shadows", "No entity shadows", true),
			Setting.toggle("blend", "No biome blend", true));

	public static final Module BG_LIMIT = new Module("bg_limit", "Background FPS Limit",
			"Caps FPS while the game window is in the background, so other programs get your GPU.",
			PERF, Items.COBWEB, false, null, 0, 0,
			Setting.number("fps", "FPS in background", 15, 5, 60, 5, ""));

	public static final List<Module> ALL = List.of(
			WATERMARK, FPS, FRAME_TIME, FPS_STATS, PING, CPS, SPEED, MEMORY, CLOCK, DATE, SESSION, COORDS, NETHER, CHUNK,
			COMPASS_M, LIGHT, LOOKING_AT, SERVER, ONLINE, NEARBY,
			KEYSTROKES, ARMOR_STATUS, POTIONS, SPRINT, HEALTH, HUNGER, SATURATION, XP, AIR, ARMOR_POINTS, HELD, OFFHAND,
			TOTEMS, GAPPLES, PEARLS, ARROWS, CRYSTALS, SPLASH, LOW_HEALTH, DURA_WARN,
			TARGET, COMBO, REACH, HITBOX, CLOSEST, CHARGE,
			REACH_ASSIST, HIT_TIMING, AUTO_HIT, CRYSTAL_OPTIMIZER, TOTEM_WARNING, TOTEM_HELPER,
			FULLBRIGHT, NIGHT_VISION, ZOOM, FOV_CHANGER, NO_BOB, NO_CLOUDS, ALWAYS_SPRINT, AUTO_WALK, AUTO_RESPAWN, ANTI_AFK,
			SNAP_TAP, UNLIMITED_FPS, NO_VSYNC, THEME, TITLE,
			FPS_BOOST, BG_LIMIT);

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private Modules() {
	}

	public static List<Module> in(String category) {
		List<Module> out = new ArrayList<>();
		for (Module m : ALL) {
			if (m.category.equals(category)) {
				out.add(m);
			}
		}
		return out;
	}

	// ------------------------------------------------------------ save / load

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("emeraldclient.json");
	}

	public static void load() {
		Path f = file();
		if (!Files.exists(f)) {
			return;
		}
		try {
			JsonObject root = GSON.fromJson(Files.readString(f), JsonObject.class);
			if (root == null) {
				return;
			}
			for (Module m : ALL) {
				if (!root.has(m.id)) {
					continue;
				}
				JsonObject o = root.getAsJsonObject(m.id);
				if (o.has("enabled")) {
					m.enabled = o.get("enabled").getAsBoolean();
					m.animOn = m.enabled ? 1 : 0;
					m.spring[0] = m.animOn;
				}
				if (o.has("x")) {
					m.fx = o.get("x").getAsDouble();
				}
				if (o.has("y")) {
					m.fy = o.get("y").getAsDouble();
				}
				for (Setting s : m.settings) {
					if (o.has(s.id)) {
						s.set(o.get(s.id).getAsDouble());
					}
				}
			}
			if (root.has("_backup")) {
				backup = GSON.fromJson(root.get("_backup"), Backup.class);
			}
		} catch (IOException | RuntimeException e) {
			System.err.println("[Emerald Client] could not read config: " + e);
		}
	}

	public static void save() {
		JsonObject root = new JsonObject();
		for (Module m : ALL) {
			JsonObject o = new JsonObject();
			o.addProperty("enabled", m.enabled);
			if (m.hasHud()) {
				o.addProperty("x", m.fx);
				o.addProperty("y", m.fy);
			}
			for (Setting s : m.settings) {
				o.addProperty(s.id, s.value);
			}
			root.add(m.id, o);
		}
		root.add("_backup", GSON.toJsonTree(backup));
		try {
			Path target = file();
			Path tmp = target.resolveSibling("emeraldclient.json.tmp");
			Files.writeString(tmp, GSON.toJson(root));
			try {
				Files.move(tmp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException atomicFailed) {
				Files.move(tmp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException e) {
			System.err.println("[Emerald Client] could not save config: " + e);
		}
	}
}
