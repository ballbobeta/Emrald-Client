package com.emeraldclient;

import java.util.Random;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;

/** Gives the world list, server list and related vanilla screens the green Emerald background. */
public final class MenuSkin {
	private static final int N = 60;
	private static final float[] PX = new float[N];
	private static final float[] PY = new float[N];
	private static final float[] PS = new float[N];
	private static final float[] PV = new float[N];
	private static final long START = System.nanoTime();

	static {
		Random r = new Random(5);
		for (int i = 0; i < N; i++) {
			PX[i] = r.nextFloat();
			PY[i] = r.nextFloat();
			PS[i] = 1 + r.nextInt(3);
			PV[i] = 0.02F + r.nextFloat() * 0.05F;
		}
	}

	private MenuSkin() {
	}

	private static boolean themed(Screen screen) {
		switch (screen.getClass().getSimpleName()) {
			case "SelectWorldScreen", "JoinMultiplayerScreen", "CreateWorldScreen", "EditServerScreen", "DirectJoinServerScreen":
				return true;
			default:
				return false;
		}
	}

	public static void register() {
		ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
			if (!Modules.THEME.enabled || !themed(screen)) {
				return;
			}
			ScreenEvents.afterBackground(screen).register((s, g, mx, my, dt) -> Safe.run("menu skin", () -> background(g)));
			ScreenEvents.afterExtract(screen).register((s, g, mx, my, dt) -> Safe.run("menu skin", () -> badge(g, s)));
		});
	}

	private static void background(GuiGraphicsExtractor g) {
		float time = (System.nanoTime() - START) / 1_000_000_000.0F;
		int w = g.guiWidth();
		int h = g.guiHeight();
		Gfx.alpha = 1.0F;
		int strips = 40;
		for (int i = 0; i < strips; i++) {
			float t = i / (float) (strips - 1);
			g.fill(0, h * i / strips, w, h * (i + 1) / strips, Gfx.lerp(0xFF020805, 0xFF0A3B22, (float) Math.pow(t, 1.6)));
		}
		int bandX = (int) ((Math.sin(time * 0.35) * 0.5 + 0.5) * w);
		Gfx.gradientH(g, bandX - 160, 0, 160, h, 0x00000000, 0x1A2ECC71);
		Gfx.gradientH(g, bandX, 0, 160, h, 0x1A2ECC71, 0x00000000);
		for (int i = 0; i < N; i++) {
			float y = ((PY[i] - time * PV[i]) % 1.0F + 1.0F) % 1.0F;
			int x = (int) ((PX[i] + (float) Math.sin(time * 0.8 + i) * 0.01F) * w);
			int yy = (int) (y * h);
			int s = (int) PS[i];
			int a = (int) (40 + 60 * (0.5 + 0.5 * Math.sin(time * 1.5 + i * 1.7)));
			g.fill(x, yy, x + s, yy + s, Gfx.withAlpha(i % 5 == 0 ? Gfx.ACCENT2 : Gfx.ACCENT, a));
		}
	}

	private static void badge(GuiGraphicsExtractor g, Screen screen) {
		Font font = Minecraft.getInstance().font;
		Gfx.alpha = 1.0F;
		Gfx.round(g, 8, 6, 8 + font.width("EMERALD") + 14, 22, 6, 0xCC08140D);
		Gfx.text(g, font, "EMERALD", 15, 11, Gfx.ACCENT2);
		Gfx.shimmerH(g, 0, 33, g.guiWidth(), 1, Gfx.ACCENT, Gfx.ACCENT2);
	}
}
