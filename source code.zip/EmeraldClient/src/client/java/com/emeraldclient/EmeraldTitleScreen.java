package com.emeraldclient;

import java.lang.reflect.Constructor;
import java.util.Random;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** The Emerald main menu: animated green background, big logo, buttons and a status card. */
public class EmeraldTitleScreen extends Screen {
	private static final String VERSION = "2.0.0";
	private static final int BTN_W = 220;
	private static final int BTN_H = 28;
	private static final int BTN_GAP = 8;
	private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Modules", "Options", "Quit Game"};
	private static final String[] SUBS = {"Play offline worlds", "Join a server", "Turn features on and off", "Video, controls, sound", "Close Minecraft"};

	private final float[] px = new float[70];
	private final float[] py = new float[70];
	private final float[] ps = new float[70];
	private final float[] pv = new float[70];
	private final float[] hover = new float[LABELS.length];
	private float time;
	private float intro;
	private long lastNs = System.nanoTime();
	private float vanillaHover;
	private String error = "";

	public EmeraldTitleScreen() {
		super(Component.literal("Emerald Client"));
		Random r = new Random(11);
		for (int i = 0; i < px.length; i++) {
			px[i] = r.nextFloat();
			py[i] = r.nextFloat();
			ps[i] = 1 + r.nextInt(4);
			pv[i] = 0.01F + r.nextFloat() * 0.04F;
		}
	}

	public boolean shouldCloseOnEsc() {
		return false;
	}

	public boolean isPauseScreen() {
		return false;
	}

	private int btnX() {
		return this.width / 2 - BTN_W / 2;
	}

	private int btnY(int i) {
		int top = this.height / 2 - 38;
		return top + i * (BTN_H + BTN_GAP);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		try {
			draw(g, mouseX, mouseY);
		} catch (Throwable t) {
			Safe.report("title screen draw", t);
			Gfx.alpha = 1.0F;
			Features.vanillaTitle = true;
			Minecraft.getInstance().setScreen(new TitleScreen());
		}
	}

	private void draw(GuiGraphicsExtractor g, int mouseX, int mouseY) {
		long now = System.nanoTime();
		float dt = Math.min(0.05F, (now - lastNs) / 1_000_000_000.0F);
		lastNs = now;
		time += dt;
		intro = Gfx.approach(intro, 1.0F, dt, 3.0F);
		Gfx.alpha = 1.0F;
		Font font = Minecraft.getInstance().font;
		int w = this.width;
		int h = this.height;

		// background: vertical gradient in strips
		int strips = 48;
		for (int i = 0; i < strips; i++) {
			int y1 = h * i / strips;
			int y2 = h * (i + 1) / strips;
			float t = i / (float) (strips - 1);
			g.fill(0, y1, w, y2, Gfx.lerp(0xFF020805, 0xFF0A3B22, (float) Math.pow(t, 1.6)));
		}
		// soft light band sliding sideways
		int bandX = (int) ((Math.sin(time * 0.35) * 0.5 + 0.5) * w);
		Gfx.gradientH(g, bandX - 160, 0, 160, h, 0x00000000, 0x1A2ECC71);
		Gfx.gradientH(g, bandX, 0, 160, h, 0x1A2ECC71, 0x00000000);

		// rising particles
		for (int i = 0; i < px.length; i++) {
			py[i] -= pv[i] * dt;
			if (py[i] < -0.05F) {
				py[i] = 1.05F;
			}
			float sway = (float) Math.sin(time * 0.8 + i) * 0.01F;
			int x = (int) ((px[i] + sway) * w);
			int y = (int) (py[i] * h);
			int s = (int) ps[i];
			int a = (int) (40 + 60 * (0.5 + 0.5 * Math.sin(time * 1.5 + i * 1.7)));
			g.fill(x, y, x + s, y + s, Gfx.withAlpha(i % 5 == 0 ? Gfx.ACCENT2 : Gfx.ACCENT, a));
		}

		// logo
		float e = Gfx.easeOutCubic(intro);
		int logoY = h / 2 - 118 + (int) ((1 - e) * -20);
		Gfx.alpha = e;
		String title = "EMERALD";
		float scale = 4.0F;
		int tw = (int) (font.width(title) * scale);
		int tx = (w - tw) / 2;
		Gfx.scaledText(g, font, title, tx + 2, logoY + 2, 0xFF04180D, scale);
		Gfx.scaledText(g, font, title, tx, logoY, Gfx.ACCENT2, scale);
		int ruleW = tw;
		Gfx.shimmerH(g, tx, logoY + 36, ruleW, 2, Gfx.ACCENT, Gfx.ACCENT2);
		Gfx.centered(g, font, "C L I E N T   -   Minecraft 26.1.2", w / 2, logoY + 44, Gfx.MUTED);

		// buttons
		for (int i = 0; i < LABELS.length; i++) {
			float stagger = Gfx.easeOutCubic(Gfx.clamp01(intro * 1.6F - i * 0.12F));
			Gfx.alpha = stagger;
			int x = btnX();
			int y = btnY(i) + (int) ((1 - stagger) * 14);
			boolean over = mouseX >= x && mouseX < x + BTN_W && mouseY >= btnY(i) && mouseY < btnY(i) + BTN_H;
			hover[i] = Gfx.approach(hover[i], over ? 1 : 0, dt, 16.0F);
			int grow = Math.round(hover[i] * 6);
			Gfx.round(g, x - grow, y, x + BTN_W + grow, y + BTN_H, 7, Gfx.lerp(0xE0101C15, Gfx.ACCENT, hover[i] * 0.9F));
			Gfx.round(g, x - grow, y + 6, x - grow + 3, y + BTN_H - 6, 1, Gfx.ACCENT2);
			int main = Gfx.lerp(Gfx.TEXT, 0xFF04120A, hover[i]);
			int sub = Gfx.lerp(Gfx.DIM, 0xFF0A3B22, hover[i]);
			Gfx.text(g, font, LABELS[i], x + 16, y + 6, main);
			Gfx.text(g, font, SUBS[i], x + 16, y + 17, sub);
		}
		Gfx.alpha = 1.0F;

		// status card (top right)
		drawCard(g, font);

		// footer
		Gfx.text(g, font, "Emerald Client " + VERSION, 10, h - 14, Gfx.DIM);
		boolean overV = mouseX >= w - 120 && mouseX < w - 8 && mouseY >= h - 20 && mouseY < h - 6;
		vanillaHover = Gfx.approach(vanillaHover, overV ? 1 : 0, dt, 14.0F);
		Gfx.text(g, font, "Vanilla menu", w - 8 - font.width("Vanilla menu"), h - 14, Gfx.lerp(Gfx.DIM, Gfx.ACCENT2, vanillaHover));
		if (!error.isEmpty()) {
			Gfx.centered(g, font, error, w / 2, btnY(LABELS.length) + 4, 0xFFFF5C5C);
		}
		Gfx.alpha = 1.0F;
	}

	private void drawCard(GuiGraphicsExtractor g, Font font) {
		int on = 0;
		for (Module m : Modules.ALL) {
			if (m.enabled) {
				on++;
			}
		}
		int cw = 150;
		int ch = 62;
		int x = this.width - cw - 12;
		int y = 12;
		Gfx.alpha = Gfx.easeOutCubic(intro);
		Gfx.round(g, x, y, x + cw, y + ch, 8, 0xCC08140D);
		Gfx.gradientH(g, x + 8, y + 1, cw - 16, 1, Gfx.ACCENT, Gfx.withAlpha(Gfx.ACCENT2, 0));
		Gfx.text(g, font, "STATUS", x + 10, y + 8, Gfx.ACCENT2);
		Gfx.text(g, font, "Modules on", x + 10, y + 22, Gfx.MUTED);
		Gfx.text(g, font, on + " / " + Modules.ALL.size(), x + cw - 10 - font.width(on + " / " + Modules.ALL.size()), y + 22, Gfx.TEXT);
		Gfx.text(g, font, "FPS Boost", x + 10, y + 34, Gfx.MUTED);
		String fb = Modules.FPS_BOOST.enabled ? "ON" : "OFF";
		Gfx.text(g, font, fb, x + cw - 10 - font.width(fb), y + 34, Modules.FPS_BOOST.enabled ? Gfx.ACCENT : Gfx.DIM);
		Gfx.text(g, font, "Menu key", x + 10, y + 46, Gfx.MUTED);
		Gfx.text(g, font, "Right Shift", x + cw - 10 - font.width("Right Shift"), y + 46, Gfx.TEXT);
		Gfx.alpha = 1.0F;
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (event.button() == 0) {
			double mx = event.x();
			double my = event.y();
			for (int i = 0; i < LABELS.length; i++) {
				if (mx >= btnX() && mx < btnX() + BTN_W && my >= btnY(i) && my < btnY(i) + BTN_H) {
					activate(i);
					return true;
				}
			}
			if (mx >= this.width - 120 && my >= this.height - 20 && my < this.height - 6) {
				Features.vanillaTitle = true;
				Minecraft.getInstance().setScreen(new TitleScreen());
				return true;
			}
		}
		return super.mouseClicked(event, doubleClick);
	}

	private void activate(int i) {
		Minecraft mc = Minecraft.getInstance();
		error = "";
		switch (i) {
			case 0 -> {
				if (!open("net.minecraft.client.gui.screens.worldselection.SelectWorldScreen", false) && error.isEmpty()) {
					error = "World list not found - use the Vanilla menu (bottom right)";
				}
			}
			case 1 -> {
				if (!open("net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen", false) && error.isEmpty()) {
					error = "Server list not found - use the Vanilla menu (bottom right)";
				}
			}
			case 2 -> mc.setScreen(new ClickGuiScreen(this));
			case 3 -> {
				if (!open("net.minecraft.client.gui.screens.options.OptionsScreen", true)
						&& !open("net.minecraft.client.gui.screens.OptionsScreen", true) && error.isEmpty()) {
					error = "Options screen not found - use the Vanilla menu (bottom right)";
				}
			}
			default -> mc.stop();
		}
	}

	/** Opens a vanilla screen by class name, filling constructor arguments we know (parent screen, options, flags). */
	private boolean open(String className, boolean withOptions) {
		Minecraft mc = Minecraft.getInstance();
		StringBuilder seen = new StringBuilder();
		try {
			Class<?> c = Class.forName(className);
			for (Constructor<?> k : c.getDeclaredConstructors()) {
				Class<?>[] t = k.getParameterTypes();
				seen.append(" (");
				for (int i = 0; i < t.length; i++) {
					seen.append(i == 0 ? "" : ",").append(t[i].getSimpleName());
				}
				seen.append(")");
				Object[] args = new Object[t.length];
				boolean ok = t.length > 0;
				for (int i = 0; i < t.length && ok; i++) {
					Class<?> p = t[i];
					if (p.isAssignableFrom(this.getClass()) && p != Object.class) {
						args[i] = this;
					} else if (mc.options != null && p.isInstance(mc.options)) {
						args[i] = mc.options;
					} else if (p == boolean.class) {
						args[i] = Boolean.FALSE;
					} else if (p == int.class) {
						args[i] = 0;
					} else {
						ok = false;
					}
				}
				if (!ok) {
					continue;
				}
				try {
					k.setAccessible(true);
					mc.setScreen((Screen) k.newInstance(args));
					return true;
				} catch (Throwable t2) {
					seen.append(" failed:").append(t2.getClass().getSimpleName());
				}
			}
			error = c.getSimpleName() + " constructors:" + seen;
		} catch (ClassNotFoundException e) {
			return false;
		} catch (Throwable t) {
			error = "Could not open: " + t;
		}
		return false;
	}
}
