package com.emeraldclient;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;

import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;

/** Things that act for you: Totem Helper and Auto Hit. Called once at the start of every client tick. */
public final class Automation {
	/** 0 = idle, 1 = hotbar key pressed (press swap-hands next tick), 2 = press the old hotbar key again. */
	private static int stage = 0;
	private static int previousSlot = 0;
	private static int helperSlot = 0;
	private static int cooldownTicks = 0;

	private Automation() {
	}

	// ------------------------------------------------------------ totem helpers

	public static boolean offhandHasTotem(LocalPlayer p) {
		return p.getOffhandItem().is(Items.TOTEM_OF_UNDYING);
	}

	/** Totems in main inventory + hotbar + offhand. */
	public static int countTotems(LocalPlayer p) {
		int n = 0;
		for (int i = 0; i < 36; i++) {
			ItemStack s = p.getInventory().getItem(i);
			if (s.is(Items.TOTEM_OF_UNDYING)) {
				n += s.getCount();
			}
		}
		ItemStack off = p.getOffhandItem();
		if (off.is(Items.TOTEM_OF_UNDYING)) {
			n += off.getCount();
		}
		return n;
	}

	/** Hotbar slot 0-8 holding a totem, or -1. The slot you already hold is preferred. */
	public static int hotbarTotemSlot(LocalPlayer p) {
		int current = p.getInventory().getSelectedSlot();
		if (p.getInventory().getItem(current).is(Items.TOTEM_OF_UNDYING)) {
			return current;
		}
		for (int i = 0; i < 9; i++) {
			if (p.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) {
				return i;
			}
		}
		return -1;
	}

	// ------------------------------------------------------------ main tick

	public static void tick(Minecraft mc) {
		LocalPlayer p = mc.player;
		if (p == null || mc.level == null) {
			stage = 0;
			return;
		}
		totemHelper(mc, p);
		autoHit(mc, p);
	}

	/** Simulates a real press of the key bound to this mapping (the game then handles it like normal input). */
	private static void press(KeyMapping mapping) {
		KeyMapping.click(KeyMappingHelper.getBoundKeyOf(mapping));
	}

	/**
	 * Totem Helper, done only with simulated key presses:
	 *  1. press the hotbar key of the slot that holds a totem
	 *  2. next tick press the swap-hands key (F by default) -> totem goes to the offhand
	 *  3. next tick press the hotbar key of the slot you were holding before
	 */
	private static void totemHelper(Minecraft mc, LocalPlayer p) {
		if (stage == 1) {
			press(mc.options.keySwapOffhand);
			stage = 2;
			return;
		}
		if (stage == 2) {
			if (previousSlot != helperSlot) {
				press(mc.options.keyHotbarSlots[previousSlot]);
			}
			stage = 0;
			cooldownTicks = 8;
			return;
		}
		if (cooldownTicks > 0) {
			cooldownTicks--;
		}
		if (!Modules.TOTEM_HELPER.enabled || mc.screen != null || cooldownTicks > 0 || !p.isAlive()) {
			return;
		}
		float hearts = p.getHealth() / 2.0F;
		if (hearts > Modules.TOTEM_WARNING.num("warn_at") || offhandHasTotem(p)) {
			return;
		}
		int slot = hotbarTotemSlot(p);
		if (slot < 0) {
			return;
		}

		// Only swallow the player's own F press when we are actually going to act on it.
		boolean pressed = false;
		while (mc.options.keySwapOffhand.consumeClick()) {
			pressed = true;
		}
		if (!pressed && !Modules.TOTEM_HELPER.flag("auto")) {
			return;
		}
		previousSlot = p.getInventory().getSelectedSlot();
		helperSlot = slot;
		if (slot != previousSlot) {
			press(mc.options.keyHotbarSlots[slot]);
		}
		stage = 1;
	}

	/** Auto Hit: simulates a left click when the crosshair is on an enemy in reach and your cooldown is ready. */
	private static void autoHit(Minecraft mc, LocalPlayer p) {
		if (!Modules.AUTO_HIT.enabled || mc.screen != null || mc.gameMode == null || !p.isAlive() || p.isSpectator()) {
			return;
		}
		if (Modules.AUTO_HIT.flag("need_key") && !mc.options.keyAttack.isDown()) {
			return;
		}
		if (p.isUsingItem()) {
			return;
		}
		if (!(mc.hitResult instanceof EntityHitResult hit)) {
			return;
		}
		Entity e = hit.getEntity();
		if (!(e instanceof LivingEntity target) || !target.isAlive()) {
			return;
		}
		if (Modules.AUTO_HIT.flag("players_only") && !(e instanceof Player)) {
			return;
		}
		if (Targeting.distanceToHitbox(p, e) > Modules.REACH_ASSIST.num("reach")) {
			return;
		}
		float needed = (float) (Modules.HIT_TIMING.num("hit_at") / 100.0);
		if (p.getAttackStrengthScale(0.0F) < needed || target.hurtTime > 5) {
			return;
		}
		// A normal left click: the game attacks and swings the arm by itself.
		press(mc.options.keyAttack);
	}
}
