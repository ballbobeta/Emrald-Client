package com.emeraldclient;

import java.lang.reflect.Method;

import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;

/** Reads and writes video options by name. A missing option is simply skipped, so the mod never crashes on it. */
public final class Opts {
	private Opts() {
	}

	@SuppressWarnings("unchecked")
	public static OptionInstance<Object> get(Minecraft mc, String name) {
		try {
			Method m = mc.options.getClass().getMethod(name);
			return (OptionInstance<Object>) m.invoke(mc.options);
		} catch (Throwable t) {
			return null;
		}
	}

	public static Object read(Minecraft mc, String name) {
		OptionInstance<Object> o = get(mc, name);
		return o == null ? null : o.get();
	}

	public static void write(Minecraft mc, String name, Object value) {
		OptionInstance<Object> o = get(mc, name);
		if (o != null && value != null) {
			try {
				o.set(value);
			} catch (Throwable ignored) {
				// option rejected the value
			}
		}
	}

	/** Asks the game to write options.txt now, so restored values are what gets saved. */
	public static void saveOptions(Minecraft mc) {
		try {
			mc.options.getClass().getMethod("save").invoke(mc.options);
		} catch (Throwable ignored) {
			// not critical
		}
	}

	public static boolean windowActive(Minecraft mc) {
		try {
			return (Boolean) mc.getClass().getMethod("isWindowActive").invoke(mc);
		} catch (Throwable t) {
			return true;
		}
	}

	/** Forces one option to a value while wanted and puts the old value back afterwards. */
	public static final class Override {
		private final String name;
		private Object saved;
		private boolean on;

		public Override(String name) {
			this.name = name;
		}

		public void apply(Minecraft mc, boolean want, Object value) {
			if (mc.options == null) {
				return;
			}
			if (want) {
				if (!on) {
					saved = read(mc, name);
					on = saved != null;
				}
				if (on && !value.equals(read(mc, name))) {
					write(mc, name, value);
				}
			} else if (on) {
				write(mc, name, saved);
				on = false;
			}
		}

		/** Puts the old value back now (used when the game closes). */
		public void restore(Minecraft mc) {
			if (on && mc.options != null) {
				write(mc, name, saved);
				on = false;
			}
		}

		public boolean active() {
			return on;
		}
	}

	/** The enum constant called "OFF" of whatever type the option uses (e.g. clouds). */
	public static Object enumConstant(Object sample, String name) {
		if (sample == null || !sample.getClass().isEnum()) {
			return null;
		}
		for (Object c : sample.getClass().getEnumConstants()) {
			if (c.toString().equals(name) || ((Enum<?>) c).name().equals(name)) {
				return c;
			}
		}
		return null;
	}
}
