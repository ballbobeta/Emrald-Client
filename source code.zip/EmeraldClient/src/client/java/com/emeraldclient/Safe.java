package com.emeraldclient;

import java.util.HashSet;
import java.util.Set;

/** Runs a piece of mod code so that one bug can never crash the game: the error is logged once and skipped. */
public final class Safe {
	private static final Set<String> REPORTED = new HashSet<>();

	private Safe() {
	}

	public static void run(String what, Runnable r) {
		try {
			r.run();
		} catch (Throwable t) {
			report(what, t);
		}
	}

	public static void report(String what, Throwable t) {
		if (REPORTED.add(what)) {
			System.err.println("[Emerald Client] error in " + what + " (further errors in it are hidden): " + t);
			t.printStackTrace();
		}
	}
}
