package com.emeraldclient;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** One feature in the menu. HUD modules also have a movable box on screen. */
public final class Module {
	/** What a HUD module draws. */
	public interface Hud {
		boolean visible(Minecraft mc, Module m);

		int width(Font font, Module m, boolean preview);

		int height(Font font, Module m, boolean preview);

		void draw(GuiGraphicsExtractor g, Font font, Module m, int x, int y, boolean preview);
	}

	public final String id;
	public final String name;
	public final String description;
	public final String category;
	public boolean enabled;

	public final Hud hud;
	public double fx;
	public double fy;
	public final List<Setting> settings = new ArrayList<>();

	private final Item iconItem;
	private ItemStack iconStack;

	// animation state (not saved)
	public boolean expanded;
	public float animOn;
	public float animHover;
	public float expandAnim;
	public final float[] spring = new float[] {0.0F, 0.0F};

	public Module(String id, String name, String description, String category, Item icon, boolean enabled,
			Hud hud, double fx, double fy, Setting... extra) {
		this.id = id;
		this.name = name;
		this.description = description;
		this.category = category;
		this.iconItem = icon;
		this.enabled = enabled;
		this.hud = hud;
		this.fx = fx;
		this.fy = fy;
		if (hud != null) {
			settings.add(Setting.number("scale", "Scale", 1.0, 0.6, 2.0, 0.1, "x"));
			settings.add(Setting.toggle("bg", "Background", true));
		}
		for (Setting s : extra) {
			settings.add(s);
		}
		this.animOn = enabled ? 1 : 0;
		this.spring[0] = enabled ? 1 : 0;
	}

	public boolean hasHud() {
		return hud != null;
	}

	/** Built on first use (while drawing); ItemStacks cannot be created while the game is still loading. */
	public ItemStack icon() {
		if (iconStack == null) {
			iconStack = new ItemStack(iconItem);
		}
		return iconStack;
	}

	public Setting setting(String sid) {
		for (Setting s : settings) {
			if (s.id.equals(sid)) {
				return s;
			}
		}
		throw new IllegalArgumentException("No setting " + sid + " in " + id);
	}

	public double num(String sid) {
		return setting(sid).value;
	}

	public boolean flag(String sid) {
		return setting(sid).on();
	}
}
