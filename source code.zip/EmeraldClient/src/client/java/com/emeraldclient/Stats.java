package com.emeraldclient;

import java.util.ArrayDeque;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

/** Live numbers the HUD modules read: FPS, clicks per second, speed, combat info. */
public final class Stats {
	public static float dt = 0.016F;
	public static long frameId;
	public static int fps;
	public static int fpsMin = Integer.MAX_VALUE;
	public static int fpsMax;
	public static long fpsSum;
	public static long fpsSamples;
	public static float frameMs = 16.0F;
	public static double speed;
	public static final long SESSION_START = System.currentTimeMillis();

	// combat
	public static int combo;
	public static double lastReach = -1;
	public static long lastHitMs;
	public static LivingEntity target;
	public static long targetMs;
	private static int prevHurt;

	private static int frames;
	private static long fpsStart = System.nanoTime();
	private static long last = System.nanoTime();

	private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
	private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();
	private static boolean leftDown;
	private static boolean rightDown;

	private Stats() {
	}

	/** Call once per rendered frame. */
	public static void frame(Minecraft mc) {
		long now = System.nanoTime();
		dt = Math.min(0.1F, (now - last) / 1_000_000_000.0F);
		last = now;
		frameId++;
		frameMs += (dt * 1000.0F - frameMs) * 0.1F;
		frames++;
		if (now - fpsStart >= 500_000_000L) {
			fps = Math.round(frames * 1_000_000_000.0F / (now - fpsStart));
			frames = 0;
			fpsStart = now;
			if (mc.level != null && mc.screen == null) {
				fpsMin = Math.min(fpsMin, fps);
				fpsMax = Math.max(fpsMax, fps);
				fpsSum += fps;
				fpsSamples++;
			}
		}

		boolean l = mc.screen == null && mc.options.keyAttack.isDown();
		boolean r = mc.screen == null && mc.options.keyUse.isDown();
		long ms = now / 1_000_000L;
		if (l && !leftDown) {
			LEFT.addLast(ms);
		}
		if (r && !rightDown) {
			RIGHT.addLast(ms);
		}
		leftDown = l;
		rightDown = r;
	}

	private static int count(ArrayDeque<Long> q) {
		long cutoff = System.nanoTime() / 1_000_000L - 1000L;
		while (!q.isEmpty() && q.peekFirst() < cutoff) {
			q.pollFirst();
		}
		return q.size();
	}

	public static int cpsLeft() {
		return count(LEFT);
	}

	public static int cpsRight() {
		return count(RIGHT);
	}

	public static void resetFpsStats() {
		fpsMin = Integer.MAX_VALUE;
		fpsMax = 0;
		fpsSum = 0;
		fpsSamples = 0;
	}

	/** Called when you left-click an entity. */
	public static void onAttack(LocalPlayer p, Entity e) {
		lastReach = Math.sqrt(e.getBoundingBox().distanceToSqr(p.getEyePosition()));
		lastHitMs = System.currentTimeMillis();
		combo++;
	}

	/** Call once per game tick. */
	public static void tick(Minecraft mc) {
		LocalPlayer p = mc.player;
		if (p == null) {
			speed = 0;
			combo = 0;
			target = null;
			return;
		}
		double dx = p.getX() - p.xo;
		double dz = p.getZ() - p.zo;
		double now = Math.sqrt(dx * dx + dz * dz) * 20.0;
		speed = speed + (now - speed) * 0.3;

		if (p.hurtTime > 0 && prevHurt == 0) {
			combo = 0;
		}
		prevHurt = p.hurtTime;
		if (combo > 0 && System.currentTimeMillis() - lastHitMs > 3000L) {
			combo = 0;
		}
		if (mc.hitResult instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity le) {
			target = le;
			targetMs = System.currentTimeMillis();
		}
	}
}
