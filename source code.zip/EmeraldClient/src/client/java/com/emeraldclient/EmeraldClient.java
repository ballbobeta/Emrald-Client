package com.emeraldclient;

import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;

/** Emerald Client entry point. Right Shift opens the menu (change it in Controls). */
public class EmeraldClient implements ClientModInitializer {
	private static KeyMapping menuKey;
	private static KeyMapping zoomKey;

	@Override
	public void onInitializeClient() {
		Safe.run("load config", () -> {
			Modules.load();
			Perf.startup();
		});

		menuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.emeraldclient.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, KeyMapping.Category.MISC));
		zoomKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.emeraldclient.zoom", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, KeyMapping.Category.MISC));
		Features.zoomKey = zoomKey;

		// Runs whenever you left-click an entity.
		AttackEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
			try {
				Minecraft mc = Minecraft.getInstance();
				if (level.isClientSide() && mc.player == player) {
					Stats.onAttack(mc.player, entity);
					if (Modules.CRYSTAL_OPTIMIZER.enabled && entity.getType() == EntityType.END_CRYSTAL) {
						// The attack packet still goes out normally; we only hide the crystal on our screen right away.
						entity.discard();
					}
				}
			} catch (Throwable t) {
				Safe.report("attack hook", t);
			}
			return InteractionResult.PASS;
		});

		MenuSkin.register();

		// Before vanilla reads the keys: Snap Tap, Totem Helper, Auto Hit.
		ClientTickEvents.START_CLIENT_TICK.register(client -> {
			Safe.run("snap tap", () -> Features.snapTap(client));
			Safe.run("automation", () -> Automation.tick(client));
		});

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			Safe.run("features", () -> Features.tick(client));
			Safe.run("stats", () -> Stats.tick(client));
			Safe.run("performance", () -> Perf.tick(client));
			Safe.run("menu key", () -> {
				while (menuKey.consumeClick()) {
					if (client.screen == null && client.player != null) {
						client.setScreen(new ClickGuiScreen());
					}
				}
			});
		});

		// Put video options back when the game closes so options.txt is not left changed.
		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Safe.run("shutdown", () -> {
			Features.shutdown(client);
			Perf.shutdown(client);
			Modules.save();
			Opts.saveOptions(client);
		}));

		HudElementRegistry.attachElementAfter(
				VanillaHudElements.MISC_OVERLAYS,
				Identifier.fromNamespaceAndPath("emeraldclient", "hud"),
				HudRenderer::extract);
	}
}
