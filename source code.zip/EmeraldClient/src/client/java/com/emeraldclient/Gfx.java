package com.emeraldclient;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Drawing toolkit (emerald theme): radius corners, fades, springs, shimmer. */
public final class Gfx {
	// ---- palette
	public static final int PANEL = 0xF20A120E;
	public static final int SIDEBAR = 0xFF070E0A;
	public static final int CARD = 0xFF111C16;
	public static final int CARD_HOVER = 0xFF182A21;
	public static final int TRACK = 0xFF22352B;
	public static final int OFF = 0xFF2F4A3B;
	public static final int ACCENT = 0xFF2ECC71;
	public static final int ACCENT2 = 0xFF7DFFB0;
	public static final int TEXT = 0xFFEFFAF3;
	public static final int MUTED = 0xFF86A596;
	public static final int DIM = 0xFF55705F;

	/** Global opacity multiplier (0..1) applied by every helper below. */
	public static float alpha = 1.0F;

	private Gfx() {
	}

	// ---- per-category accent colours
	public static int accent(String category) {
		if ("Player".equals(category)) {
			return 0xFF34D399;
		}
		if ("Combat".equals(category)) {
			return 0xFF9BE564;
		}
		if ("Utility".equals(category)) {
			return 0xFF4ADE80;
		}
		if ("Performance".equals(category)) {
			return 0xFF22D3A5;
		}
		return 0xFF2ECC71;
	}

	public static int accent2(String category) {
		if ("Player".equals(category)) {
			return 0xFFA3E635;
		}
		if ("Combat".equals(category)) {
			return 0xFFE4FF8A;
		}
		if ("Utility".equals(category)) {
			return 0xFF86EFAC;
		}
		if ("Performance".equals(category)) {
			return 0xFF67E8F9;
		}
		return 0xFF7DFFB0;
	}

	// ---- colour maths
	private static int a(int c) {
		if (alpha >= 0.999F) {
			return c;
		}
		int al = Math.round(((c >>> 24) & 255) * Math.max(0.0F, alpha));
		return (al << 24) | (c & 0x00FFFFFF);
	}

	public static int lerp(int a, int b, float t) {
		t = Math.max(0, Math.min(1, t));
		int aa = (a >>> 24) & 255, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
		int ba = (b >>> 24) & 255, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
		int ra = (int) (aa + (ba - aa) * t);
		int rr = (int) (ar + (br - ar) * t);
		int rg = (int) (ag + (bg - ag) * t);
		int rb = (int) (ab + (bb - ab) * t);
		return (ra << 24) | (rr << 16) | (rg << 8) | rb;
	}

	public static int withAlpha(int color, int alpha) {
		return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
	}

	// ---- shapes
	public static void fill(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int c) {
		g.fill(x1, y1, x2, y2, a(c));
	}

	public static void round(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int c) {
		round(g, x1, y1, x2, y2, 3, c);
	}

	/** Rounded box. Rows never overlap, so translucent colours stay even. */
	public static void round(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int r, int c) {
		int w = x2 - x1;
		int h = y2 - y1;
		if (w <= 0 || h <= 0) {
			return;
		}
		r = Math.min(r, Math.min(w, h) / 2);
		int col = a(c);
		if (r <= 0) {
			g.fill(x1, y1, x2, y2, col);
			return;
		}
		for (int k = 0; k < r; k++) {
			double dy = r - k - 0.5;
			int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
			g.fill(x1 + inset, y1 + k, x2 - inset, y1 + k + 1, col);
			g.fill(x1 + inset, y2 - k - 1, x2 - inset, y2 - k, col);
		}
		if (h - 2 * r > 0) {
			g.fill(x1, y1 + r, x2, y2 - r, col);
		}
	}

	public static void gradientH(GuiGraphicsExtractor g, int x, int y, int w, int h, int c1, int c2) {
		int step = 2;
		for (int i = 0; i < w; i += step) {
			float t = w <= 1 ? 0 : (float) i / (w - 1);
			g.fill(x + i, y, Math.min(x + w, x + i + step), y + h, a(lerp(c1, c2, t)));
		}
	}

	/** Gradient that slowly flows sideways. */
	public static void shimmerH(GuiGraphicsExtractor g, int x, int y, int w, int h, int c1, int c2) {
		double time = System.nanoTime() / 1_000_000_000.0;
		int step = 2;
		for (int i = 0; i < w; i += step) {
			float t = (float) (0.5 + 0.5 * Math.sin(time * 1.6 + i * 0.028));
			g.fill(x + i, y, Math.min(x + w, x + i + step), y + h, a(lerp(c1, c2, t)));
		}
	}

	/** Switch. pos: 0 = off, 1 = on (may overshoot slightly for a springy knob). */
	public static void toggle(GuiGraphicsExtractor g, int x, int y, int w, int h, float pos, int onColor) {
		float p = Math.max(0.0F, Math.min(1.0F, pos));
		round(g, x, y, x + w, y + h, h / 2, lerp(OFF, onColor, p));
		int knob = h - 4;
		int kx = x + 2 + Math.round((w - knob - 4) * pos);
		round(g, kx, y + 2, kx + knob, y + 2 + knob, knob / 2, 0xFFFFFFFF);
	}

	// ---- text
	public static void text(GuiGraphicsExtractor g, Font font, String s, int x, int y, int c) {
		g.text(font, s, x, y, a(c));
	}

	public static void centered(GuiGraphicsExtractor g, Font font, String s, int cx, int y, int c) {
		g.centeredText(font, s, cx, y, a(c));
	}

	public static void scaledText(GuiGraphicsExtractor g, Font font, String s, int x, int y, int c, float scale) {
		g.pose().pushMatrix();
		g.pose().translate((float) x, (float) y);
		g.pose().scale(scale);
		g.text(font, s, 0, 0, a(c));
		g.pose().popMatrix();
	}

	// ---- motion
	/** Frame-rate independent smoothing toward a target. */
	public static float approach(float value, float target, float dtSeconds, float speed) {
		float k = 1.0F - (float) Math.exp(-speed * dtSeconds);
		return value + (target - value) * k;
	}

	/** Under-damped spring: state[0] = position, state[1] = velocity. Gives a small overshoot. */
	public static void spring(float[] state, float target, float dtSeconds) {
		int steps = 4;
		float h = Math.min(dtSeconds, 0.05F) / steps;
		for (int i = 0; i < steps; i++) {
			float acc = 300.0F * (target - state[0]) - 21.0F * state[1];
			state[1] += acc * h;
			state[0] += state[1] * h;
		}
	}

	public static float clamp01(float v) {
		return Math.max(0.0F, Math.min(1.0F, v));
	}

	public static float easeOutCubic(float t) {
		t = clamp01(t);
		float u = 1.0F - t;
		return 1.0F - u * u * u;
	}
}
