package com.emeraldclient;

/**
 * One HUD text line: a muted label and a coloured value.
 * bar >= 0 draws a thin progress bar under the line (0..1); big = larger headline text.
 */
public record Line(String label, String value, int color, float bar, boolean big) {
	public Line(String label, String value, int color) {
		this(label, value, color, -1.0F, false);
	}

	public static Line headline(String text, int color) {
		return new Line("", text, color, -1.0F, true);
	}

	public static Line withBar(String label, String value, int color, float bar) {
		return new Line(label, value, color, Math.max(0.0F, Math.min(1.0F, bar)), false);
	}
}
