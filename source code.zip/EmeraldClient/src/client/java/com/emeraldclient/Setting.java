package com.emeraldclient;

/** A number slider or an ON/OFF switch belonging to a module. */
public final class Setting {
	public enum Kind { NUMBER, TOGGLE }

	public final String id;
	public final String label;
	public final String suffix;
	public final Kind kind;
	public final double min;
	public final double max;
	public final double step;
	public double value;

	private Setting(String id, String label, Kind kind, double value, double min, double max, double step, String suffix) {
		this.id = id;
		this.label = label;
		this.kind = kind;
		this.value = value;
		this.min = min;
		this.max = max;
		this.step = step;
		this.suffix = suffix;
	}

	public static Setting number(String id, String label, double def, double min, double max, double step, String suffix) {
		return new Setting(id, label, Kind.NUMBER, def, min, max, step, suffix);
	}

	public static Setting toggle(String id, String label, boolean def) {
		return new Setting(id, label, Kind.TOGGLE, def ? 1 : 0, 0, 1, 1, "");
	}

	public boolean on() {
		return value >= 0.5;
	}

	public void flip() {
		value = on() ? 0 : 1;
	}

	public void set(double v) {
		v = Math.max(min, Math.min(max, v));
		if (kind == Kind.NUMBER && step > 0) {
			v = Math.round((v - min) / step) * step + min;
			v = Math.max(min, Math.min(max, v));
		}
		value = v;
	}

	public float fraction() {
		return (float) ((value - min) / (max - min));
	}

	public String display() {
		if (kind == Kind.TOGGLE) {
			return on() ? "ON" : "OFF";
		}
		if (step >= 1) {
			return Math.round(value) + suffix;
		}
		return String.format("%.1f%s", value, suffix);
	}
}
