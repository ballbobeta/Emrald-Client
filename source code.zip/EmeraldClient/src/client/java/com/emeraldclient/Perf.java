package com.emeraldclient;

import net.minecraft.client.Minecraft;

/** FPS Boost and Background FPS Limit. Only touches ordinary video options and puts them back when switched off. */
public final class Perf {
	private static boolean boosted;
	private static boolean wasBackground;
	private static Object savedLimit;

	private Perf() {
	}

	public static boolean inBackground() {
		return wasBackground;
	}

	public static void tick(Minecraft mc) {
		if (mc.options == null) {
			return;
		}
		boolean want = Modules.FPS_BOOST.enabled;
		if (want && !boosted) {
			apply(mc);
		} else if (!want && boosted) {
			restore(mc);
		}

		if (Modules.BG_LIMIT.enabled) {
			boolean bg = !Opts.windowActive(mc);
			if (bg && !wasBackground) {
				savedLimit = Opts.read(mc, "framerateLimit");
				Opts.write(mc, "framerateLimit", (int) Modules.BG_LIMIT.num("fps"));
				wasBackground = true;
			} else if (!bg && wasBackground) {
				Opts.write(mc, "framerateLimit", savedLimit != null ? savedLimit : (Object) 260);
				wasBackground = false;
			}
		} else if (wasBackground) {
			Opts.write(mc, "framerateLimit", savedLimit != null ? savedLimit : (Object) 260);
			wasBackground = false;
		}
	}

	private static int asInt(Object o, int def) {
		return o instanceof Number n ? n.intValue() : def;
	}

	private static double asDouble(Object o, double def) {
		return o instanceof Number n ? n.doubleValue() : def;
	}

	private static void apply(Minecraft mc) {
		Modules.Backup b = Modules.backup;
		if (b.renderDistance < 0) {
			b.renderDistance = asInt(Opts.read(mc, "renderDistance"), 12);
			b.simulationDistance = asInt(Opts.read(mc, "simulationDistance"), 12);
			b.entityScaling = asDouble(Opts.read(mc, "entityDistanceScaling"), 1.0);
			b.entityShadows = !Boolean.FALSE.equals(Opts.read(mc, "entityShadows"));
			b.biomeBlend = asInt(Opts.read(mc, "biomeBlendRadius"), 2);
			Modules.save();
		}
		int rd = (int) Modules.FPS_BOOST.num("render");
		int sd = (int) Modules.FPS_BOOST.num("sim");
		Opts.write(mc, "renderDistance", Math.min(b.renderDistance, rd));
		Opts.write(mc, "simulationDistance", Math.min(b.simulationDistance, sd));
		if (Modules.FPS_BOOST.flag("entities")) {
			Opts.write(mc, "entityDistanceScaling", Math.min(b.entityScaling, 0.75));
		}
		if (Modules.FPS_BOOST.flag("shadows")) {
			Opts.write(mc, "entityShadows", false);
		}
		if (Modules.FPS_BOOST.flag("blend")) {
			Opts.write(mc, "biomeBlendRadius", 0);
		}
		boosted = true;
	}

	private static void restore(Minecraft mc) {
		Modules.Backup b = Modules.backup;
		if (b.renderDistance >= 0) {
			Opts.write(mc, "renderDistance", b.renderDistance);
			Opts.write(mc, "simulationDistance", b.simulationDistance);
			Opts.write(mc, "entityDistanceScaling", b.entityScaling);
			Opts.write(mc, "entityShadows", b.entityShadows);
			Opts.write(mc, "biomeBlendRadius", b.biomeBlend);
			b.renderDistance = -1;
			Modules.save();
		}
		boosted = false;
	}

	/** Game is closing: put the original video options back so options.txt is not left changed. */
	public static void shutdown(Minecraft mc) {
		if (mc.options == null) {
			return;
		}
		if (boosted) {
			restore(mc);
		}
		if (wasBackground) {
			Opts.write(mc, "framerateLimit", savedLimit != null ? savedLimit : (Object) 260);
			wasBackground = false;
		}
	}

	public static void startup() {
		boosted = Modules.backup.renderDistance >= 0 && Modules.FPS_BOOST.enabled;
	}
}
