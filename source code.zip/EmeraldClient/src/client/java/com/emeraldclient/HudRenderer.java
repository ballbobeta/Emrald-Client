package com.emeraldclient;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Lays out and draws the HUD boxes (in-game and in the HUD editor). */
public final class HudRenderer {
	public record Box(Module module, int x, int y, int w, int h, float scale) {
		public boolean contains(double mx, double my) {
			return mx >= x && mx < x + w && my >= y && my < y + h;
		}
	}

	private HudRenderer() {
	}

	/** In-game HUD callback. */
	public static void extract(GuiGraphicsExtractor g, DeltaTracker delta) {
		Minecraft mc = Minecraft.getInstance();
		try {
			Stats.frame(mc);
			tickAnimation();
			if (mc.player == null || mc.options.hideGui || mc.screen instanceof HudEditorScreen) {
				return;
			}
			draw(g, layout(mc, g.guiWidth(), g.guiHeight(), false), null);
		} catch (Throwable t) {
			Safe.report("HUD", t);
		} finally {
			Gfx.alpha = 1.0F;
		}
	}

	public static void tickAnimation() {
		float dt = Stats.dt;
		for (Module m : Modules.ALL) {
			m.animOn = Gfx.approach(m.animOn, m.enabled ? 1 : 0, dt, 14.0F);
		}
	}

	public static List<Box> layout(Minecraft mc, int sw, int sh, boolean preview) {
		Font font = mc.font;
		List<Box> out = new ArrayList<>();
		for (Module m : Modules.ALL) {
			if (!m.hasHud() || m.animOn < 0.02F) {
				continue;
			}
			try {
				if (!preview && !m.hud.visible(mc, m)) {
					continue;
				}
			} catch (Throwable t) {
				Safe.report("HUD " + m.id, t);
				continue;
			}
			float scale = (float) m.num("scale");
			int w0;
			int h0;
			try {
				w0 = m.hud.width(font, m, preview);
				h0 = m.hud.height(font, m, preview);
			} catch (Throwable t) {
				Safe.report("HUD size " + m.id, t);
				continue;
			}
			int w = Math.round(w0 * scale);
			int h = Math.round(h0 * scale);
			int x = (int) Math.round(m.fx * sw);
			int y = (int) Math.round(m.fy * sh);
			x = Math.max(0, Math.min(sw - w, x));
			y = Math.max(0, Math.min(sh - h, y));
			out.add(new Box(m, x, y, w, h, scale));
		}
		return out;
	}

	public static void draw(GuiGraphicsExtractor g, List<Box> boxes, Module highlight) {
		Font font = Minecraft.getInstance().font;
		for (Box b : boxes) {
			Module m = b.module();
			boolean preview = Minecraft.getInstance().screen instanceof HudEditorScreen;
			Gfx.alpha = Gfx.clamp01(m.animOn);
			int w0 = m.hud.width(font, m, preview);
			int h0 = m.hud.height(font, m, preview);
			g.pose().pushMatrix();
			try {
				g.pose().translate((float) b.x(), (float) b.y());
				g.pose().scale(b.scale());
				if (m.flag("bg")) {
					Gfx.round(g, 0, 0, w0, h0, 4, 0x8C07110B);
					Gfx.round(g, 0, 2, 2, h0 - 2, 1, Gfx.accent(m.category));
				}
				m.hud.draw(g, font, m, 0, 0, preview);
			} catch (Throwable t) {
				Safe.report("HUD draw " + m.id, t);
				m.enabled = false;
			} finally {
				g.pose().popMatrix();
			}
			if (m == highlight) {
				Gfx.fill(g, b.x() - 1, b.y() - 1, b.x() + b.w() + 1, b.y(), Gfx.ACCENT2);
				Gfx.fill(g, b.x() - 1, b.y() + b.h(), b.x() + b.w() + 1, b.y() + b.h() + 1, Gfx.ACCENT2);
				Gfx.fill(g, b.x() - 1, b.y(), b.x(), b.y() + b.h(), Gfx.ACCENT2);
				Gfx.fill(g, b.x() + b.w(), b.y(), b.x() + b.w() + 1, b.y() + b.h(), Gfx.ACCENT2);
			}
		}
		Gfx.alpha = 1.0F;
	}
}
