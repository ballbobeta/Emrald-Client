package com.emeraldclient;

import org.lwjgl.glfw.GLFW;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;

/** The modules that change how the game behaves (no HUD box). Runs once per client tick. */
public final class Features {
	public static KeyMapping zoomKey;
	public static boolean vanillaTitle;

	private static final Opts.Override GAMMA = new Opts.Override("gamma");
	private static final Opts.Override FOV = new Opts.Override("fov");
	private static final Opts.Override BOB = new Opts.Override("bobView");
	private static final Opts.Override CLOUDS = new Opts.Override("cloudStatus");
	private static final Opts.Override VSYNC = new Opts.Override("enableVsync");
	private static final Opts.Override FRAMES = new Opts.Override("framerateLimit");

	private static boolean nvAdded;
	private static boolean sprintHeld;
	private static boolean walkHeld;
	private static int respawnTicks;
	private static int afkTicks;

	private static boolean ctrlWasDown;

	private Features() {
	}

	private static long cachedHandle;

	static long windowHandle(Minecraft mc) {
		if (cachedHandle != 0L) {
			return cachedHandle;
		}
		Object w = mc.getWindow();
		for (String name : new String[] {"handle", "getWindow"}) {
			try {
				Object r = w.getClass().getMethod(name).invoke(w);
				if (r instanceof Long l) {
					cachedHandle = l;
					return l;
				}
			} catch (Throwable ignored) {
				// try next name
			}
		}
		return 0L;
	}

	private static boolean physical(long window, KeyMapping m) {
		try {
			var key = KeyMappingHelper.getBoundKeyOf(m);
			return key.getType() == com.mojang.blaze3d.platform.InputConstants.Type.KEYSYM
					&& GLFW.glfwGetKey(window, key.getValue()) == GLFW.GLFW_PRESS;
		} catch (Throwable t) {
			return false;
		}
	}

	/**
	 * Snap Tap. For two opposite keys, the one pressed last wins; letting go of it hands control back to the other
	 * key if that is still held. Runs at the start of each tick, before the game reads the keys.
	 */
	public static void snapTap(Minecraft mc) {
		if (mc.options == null || mc.player == null || mc.screen != null || !Modules.SNAP_TAP.enabled) {
			STRAFE.prevNeg = false;
			STRAFE.prevPos = false;
			STRAFE.last = 0;
			MOVE.prevNeg = false;
			MOVE.prevPos = false;
			MOVE.last = 0;
			return;
		}
		long w = windowHandle(mc);
		if (w == 0L) {
			return;
		}
		if (Modules.SNAP_TAP.flag("strafe")) {
			axis(mc.options.keyLeft, mc.options.keyRight, w, STRAFE);
		}
		if (Modules.SNAP_TAP.flag("forward")) {
			axis(mc.options.keyUp, mc.options.keyDown, w, MOVE);
		}
	}

	/** Remembers, for one pair of opposite keys, what was held last tick and which key was pressed most recently. */
	private static final class Axis {
		boolean prevNeg;
		boolean prevPos;
		int last;
	}

	private static final Axis STRAFE = new Axis();
	private static final Axis MOVE = new Axis();

	private static void axis(KeyMapping neg, KeyMapping pos, long w, Axis a) {
		boolean n = physical(w, neg);
		boolean p = physical(w, pos);
		if (n && !a.prevNeg) {
			a.last = -1;
		}
		if (p && !a.prevPos) {
			a.last = 1;
		}
		if (!n && !p) {
			a.last = 0;
		}
		a.prevNeg = n;
		a.prevPos = p;
		if (n && p) {
			neg.setDown(a.last == -1);
			pos.setDown(a.last == 1);
		} else {
			neg.setDown(n);
			pos.setDown(p);
		}
	}

	/** On the vanilla title screen, Right Shift brings the Emerald menu back. */
	private static void vanillaTitleSwitch(Minecraft mc) {
		boolean down = false;
		if (vanillaTitle && mc.screen instanceof TitleScreen) {
			long h = windowHandle(mc);
			down = h != 0L && GLFW.glfwGetKey(h, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
			if (down && !ctrlWasDown) {
				vanillaTitle = false;
			}
		}
		ctrlWasDown = down;
	}

	private static void press(KeyMapping mapping) {
		KeyMapping.click(KeyMappingHelper.getBoundKeyOf(mapping));
	}

	/** Game is closing: restore every video option we changed. */
	public static void shutdown(Minecraft mc) {
		for (Opts.Override o : new Opts.Override[] {GAMMA, FOV, BOB, CLOUDS, VSYNC, FRAMES}) {
			o.restore(mc);
		}
		LocalPlayer p = mc.player;
		if (nvAdded && p != null) {
			p.removeEffect(MobEffects.NIGHT_VISION);
			nvAdded = false;
		}
	}

	public static void tick(Minecraft mc) {
		if (mc.options == null) {
			return;
		}
		LocalPlayer p = mc.player;

		// main menu
		vanillaTitleSwitch(mc);
		if (mc.level != null) {
			vanillaTitle = false;
		}
		if (Modules.TITLE.enabled && !vanillaTitle && mc.screen instanceof TitleScreen) {
			try {
				mc.setScreen(new EmeraldTitleScreen());
			} catch (Throwable t) {
				vanillaTitle = true;
				Safe.report("title screen", t);
			}
		}

		// video options we force while a module is on
		GAMMA.apply(mc, Modules.FULLBRIGHT.enabled, 1.0D);

		boolean zooming = Modules.ZOOM.enabled && zoomKey != null && zoomKey.isDown() && mc.screen == null;
		if (zooming) {
			FOV.apply(mc, true, (int) Modules.ZOOM.num("fov"));
		} else {
			FOV.apply(mc, Modules.FOV_CHANGER.enabled, (int) Modules.FOV_CHANGER.num("fov"));
		}

		BOB.apply(mc, Modules.NO_BOB.enabled, Boolean.FALSE);
		Object cloudOff = Opts.enumConstant(Opts.read(mc, "cloudStatus"), "OFF");
		CLOUDS.apply(mc, Modules.NO_CLOUDS.enabled && cloudOff != null, cloudOff == null ? Boolean.FALSE : cloudOff);
		VSYNC.apply(mc, Modules.NO_VSYNC.enabled, Boolean.FALSE);
		FRAMES.apply(mc, Modules.UNLIMITED_FPS.enabled && !Perf.inBackground(), 260);

		if (p == null) {
			nvAdded = false;
			respawnTicks = 0;
			// Death screen can still be open while player exists; nothing to do when it does not.
			return;
		}

		// Night Vision
		if (Modules.NIGHT_VISION.enabled) {
			if (!p.hasEffect(MobEffects.NIGHT_VISION)) {
				p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, -1, 0, false, false, false));
				nvAdded = true;
			}
		} else if (nvAdded) {
			p.removeEffect(MobEffects.NIGHT_VISION);
			nvAdded = false;
		}

		// Always Sprint
		if (Modules.ALWAYS_SPRINT.enabled && mc.screen == null && mc.options.keyUp.isDown()) {
			mc.options.keySprint.setDown(true);
			sprintHeld = true;
		} else if (sprintHeld) {
			mc.options.keySprint.setDown(false);
			sprintHeld = false;
		}

		// Auto Walk
		if (Modules.AUTO_WALK.enabled && mc.screen == null) {
			mc.options.keyUp.setDown(true);
			walkHeld = true;
		} else if (walkHeld) {
			mc.options.keyUp.setDown(false);
			walkHeld = false;
		}

		// Auto Respawn
		if (Modules.AUTO_RESPAWN.enabled && mc.screen != null && mc.screen.getClass().getSimpleName().equals("DeathScreen")) {
			if (++respawnTicks >= Modules.AUTO_RESPAWN.num("delay") * 20) {
				respawnTicks = 0;
				try {
					p.getClass().getMethod("respawn").invoke(p);
				} catch (Throwable ignored) {
					// method not available: the normal Respawn button still works
				}
			}
		} else {
			respawnTicks = 0;
		}

		// Anti AFK
		if (Modules.ANTI_AFK.enabled && mc.screen == null) {
			if (++afkTicks >= Modules.ANTI_AFK.num("secs") * 20) {
				afkTicks = 0;
				press(mc.options.keyJump);
			}
		} else {
			afkTicks = 0;
		}
	}
}
