package com.emeraldclient;

import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Opened with Enter: cursor is free, drag any HUD box where you want it. Snaps to the screen centre. */
public class HudEditorScreen extends Screen {
	private static final int SNAP = 5;

	private Module dragging;
	private double grabDx;
	private double grabDy;
	private boolean snapX;
	private boolean snapY;

	private final Screen parent;

	public HudEditorScreen() {
		this(null);
	}

	public HudEditorScreen(Screen parent) {
		super(Component.literal("Emerald Client - move HUD"));
		this.parent = parent;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		try {
			drawScreen(graphics, mouseX, mouseY, delta);
		} catch (Throwable t) {
			Safe.report("HUD editor draw", t);
			Gfx.alpha = 1.0F;
			this.onClose();
		}
	}

	private void drawScreen(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		Gfx.alpha = 1.0F;
		HudRenderer.tickAnimation();
		Font font = Minecraft.getInstance().font;

		// centre guides (brighter while snapping)
		graphics.fill(this.width / 2, 0, this.width / 2 + 1, this.height, snapX ? 0xCC7DFFB0 : 0x22FFFFFF);
		graphics.fill(0, this.height / 2, this.width, this.height / 2 + 1, snapY ? 0xCC7DFFB0 : 0x22FFFFFF);

		// top banner
		String msg = "Drag a box to move it  -  scroll to resize  -  Esc to save & close";
		int bw = font.width(msg) + 24;
		int bx = (this.width - bw) / 2;
		Gfx.round(graphics, bx, 8, bx + bw, 28, Gfx.PANEL);
		Gfx.gradientH(graphics, bx + 4, 27, bw - 8, 1, Gfx.ACCENT, Gfx.ACCENT2);
		graphics.centeredText(font, msg, this.width / 2, 14, Gfx.TEXT);

		List<HudRenderer.Box> boxes = HudRenderer.layout(Minecraft.getInstance(), this.width, this.height, true);
		HudRenderer.draw(graphics, boxes, dragging);
		for (HudRenderer.Box b : boxes) {
			boolean hot = b.contains(mouseX, mouseY) || b.module() == dragging;
			String label = b.module().name;
			int lw = font.width(label) + 10;
			int lx = b.x() - 6;
			int ly = b.y() - 22;
			Gfx.round(graphics, lx, ly, lx + lw, ly + 13, hot ? Gfx.ACCENT : 0xAA101018);
			graphics.text(font, label, lx + 5, ly + 3, hot ? 0xFFFFFFFF : Gfx.MUTED);
		}
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (event.button() == 0) {
			List<HudRenderer.Box> boxes = HudRenderer.layout(Minecraft.getInstance(), this.width, this.height, true);
			for (int i = boxes.size() - 1; i >= 0; i--) {
				HudRenderer.Box b = boxes.get(i);
				if (b.contains(event.x(), event.y())) {
					dragging = b.module();
					grabDx = event.x() - b.x();
					grabDy = event.y() - b.y();
					return true;
				}
			}
		}
		return super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
		if (dragging != null) {
			int w = 0;
			int h = 0;
			for (HudRenderer.Box b : HudRenderer.layout(Minecraft.getInstance(), this.width, this.height, true)) {
				if (b.module() == dragging) {
					w = b.w();
					h = b.h();
				}
			}
			double nx = event.x() - grabDx;
			double ny = event.y() - grabDy;

			snapX = Math.abs(nx + w / 2.0 - this.width / 2.0) < SNAP;
			snapY = Math.abs(ny + h / 2.0 - this.height / 2.0) < SNAP;
			if (snapX) {
				nx = this.width / 2.0 - w / 2.0;
			}
			if (snapY) {
				ny = this.height / 2.0 - h / 2.0;
			}
			dragging.fx = Math.max(0.0, Math.min(1.0, nx / this.width));
			dragging.fy = Math.max(0.0, Math.min(1.0, ny / this.height));
			return true;
		}
		return super.mouseDragged(event, dx, dy);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
		if (dragging != null) {
			dragging = null;
			snapX = false;
			snapY = false;
			Modules.save();
			return true;
		}
		return super.mouseReleased(event);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double sx, double sy) {
		for (HudRenderer.Box b : HudRenderer.layout(Minecraft.getInstance(), this.width, this.height, true)) {
			if (b.contains(mx, my)) {
				Setting sc = b.module().setting("scale");
				sc.set(sc.value + (sy > 0 ? 0.1 : -0.1));
				return true;
			}
		}
		return super.mouseScrolled(mx, my, sx, sy);
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		return super.keyPressed(event);
	}

	@Override
	public void onClose() {
		Modules.save();
		Minecraft.getInstance().setScreen(parent);
	}
}
