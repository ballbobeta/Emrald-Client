# Contributing to Emerald Client

First off, thanks for considering contributing to Emerald Client! It's people like you that make Emerald Client such a great tool.

## Code of Conduct

This project and everyone participating in it is governed by our Code of Conduct. By participating, you are expected to uphold this code.

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check if the bug has already been reported. When you are creating a bug report, include as many details as possible:

* **Use a clear and descriptive title**
* **Describe the exact steps which reproduce the problem**
* **Provide specific examples to demonstrate the steps**
* **Describe the behavior you observed after following the steps**
* **Explain which behavior you expected to see instead and why**
* **Include screenshots and animated GIFs if possible**

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion, include:

* **Use a clear and descriptive title**
* **Provide a step-by-step description of the suggested enhancement**
* **Provide specific examples to demonstrate the steps**
* **Describe the current behavior and the expected behavior**

### Pull Requests

* Fill in the required template
* Follow the Java/Gradle style guides
* End all files with a newline
* Avoid platform-dependent code

## Style Guides

### Java Style Guide

* Use 4-space indentation
* Use camelCase for variable and method names
* Use PascalCase for class names
* Use UPPER_CASE for constants
* Write clear, descriptive names

### Commit Messages

* Use the present tense ("Add feature" not "Added feature")
* Use the imperative mood ("Move cursor to..." not "Moves cursor to...")
* Limit the first line to 72 characters or less
* Reference issues and pull requests liberally after the first line

## Project Structure

```
EmeraldClient/
├── src/main/
│   ├── java/net/emeraldclient/
│   │   ├── module/          # Module system
│   │   ├── ui/              # UI components
│   │   ├── event/           # Event system
│   │   └── mixin/           # Mixins
│   └── resources/
│       └── assets/          # Textures, icons, sounds
└── gradle files
```

## Additional Notes

### Issue and Pull Request Labels

This section lists the labels we use to help us track and manage issues and pull requests.

* `bug` - Something isn't working
* `enhancement` - New feature or request
* `documentation` - Improvements or additions to documentation
* `good first issue` - Good for newcomers

## Recognition

All contributors will be recognized in our README.md file and CONTRIBUTORS.md file.
