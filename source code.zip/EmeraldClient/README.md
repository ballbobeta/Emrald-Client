# Emerald Client 🟢

A powerful, green-themed Fabric mod client for Minecraft Java Edition with 69 customizable modules focused on competitive PvP gameplay.

## Features

- **69 Modules** across 5 categories (Combat, Player, Utility, Render, Info)
- **Green Theme** - Customizable emerald green color (#2eff80)
- **Right Shift Menu** - Quick access to module settings
- **Draggable HUD** - Position HUD elements freely
- **High Performance** - Optimized for competitive play
- **Fabric Compatible** - Works with Minecraft 1.26.1 + Fabric 0.19.5

## Installation

1. Install [Fabric Loader](https://fabricmc.net/)
2. Download the latest release from GitHub
3. Place the `.jar` file in `~/.minecraft/mods/`
4. Launch Minecraft with the Fabric profile
5. Press `Right Shift` to open the module menu

## Module Categories

### Combat (15 modules)
Crystal Optimizer, Reach Assist, Snap Tap, Auto Hit, Velocity, Backtrack, Strafe Helper, Hit Delay, AntiKnockback, Criticals, Swing Bot, Killaura, Totem Helper, Hotbar Manager, Sharpness Viewer

### Player (12 modules)
Sprint, AutoSprint, FastFall, Flight, NoFall, AutoClip, Speed, Step, FastPlace, Jesus, NoWeb, Strider

### Utility (18 modules)
AutoMend, ClickGUI, Coordinates, Direction, FPS Display, Ping Display, TimeDisplay, Watermark, FullBright, Xray, Freecam, Zoom, ChatFilter, ItemPhysics, BetterChat, Shaders, Performance, Notifications

### Render (14 modules)
ESP, Tracers, Wireframe, Nametags, Chams, BlockESP, ItemESP, Skybox, Particles, NightVision, VoidFog, Hand, Cape, Animations

### Info (10 modules)
Inventory, EntityInfo, PlayerList, TabFPS, Metrics, Memory, Biome, NetDebug, LogViewer, Statistics

## Controls

- **Right Shift** - Open module menu
- **Customizable Keybinds** - Set per-module keybinds in settings

## Building

```bash
./gradlew build
```

Output will be in `build/libs/emeraldclient-*.jar`

## Development

### Prerequisites
- Java 21+
- Gradle 8.0+

### Setting Up Dev Environment
```bash
./gradlew genSources
```

### Running in Dev
```bash
./gradlew runClient
```

## Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

MIT License - See LICENSE file for details

## Author

Thai Developer (bopannipa@gmail.com)

---

**Version:** 2.0.0  
**Minecraft:** 1.26.1  
**Fabric API:** 0.100.8  
**Status:** Active Development
