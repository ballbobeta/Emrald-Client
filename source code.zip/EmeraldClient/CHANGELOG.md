# Changelog

All notable changes to this project will be documented in this file.

## [2.0.0] - 2026-10-20

### Added
- Initial release with 69 modules
- Combat category (15 modules)
- Player category (12 modules)
- Utility category (18 modules)
- Render category (14 modules)
- Info category (10 modules)
- Right Shift menu system
- Draggable HUD elements
- Green theme customization
- Event system for module communication
- Configuration system

### Technical
- Fabric 0.19.5 support
- Minecraft 1.26.1 compatibility
- Java 21 required
- Gradle build system
- GitHub Actions CI/CD

---

## Future Releases

### Planned for v2.1.0
- [ ] Better Chat system
- [ ] Advanced keybind system
- [ ] Config file persistence
- [ ] Module grouping
- [ ] Performance improvements

### Under Consideration
- [ ] Bedrock support
- [ ] Addon system
- [ ] Custom themes

---

**Format:** [Semantic Versioning](https://semver.org/)
